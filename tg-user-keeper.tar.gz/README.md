# TG User Keeper

`tg-user-keeper` 是独立的 Telegram 用户号守护服务，使用 Telethon 用户会话执行两类任务：

- 每日签到任务（按 `tasks.json`）
- 健康检查任务（向一个或多个目标 bot 发送 `/start`）

当前默认健康检查链路已适配你的场景：

- 探活对象可设置为 `@fakahyzybot`、接码机器人等多个 bot
- 每 5 分钟发起一次探活（可配置）
- 单次等待回复最长 300 秒，超时即进入诊断/救援链路
- 超时后先调用本机 OpenClaw/Codex 诊断，再回退到 `tg_watchdog.sh` 复活
- 可选通过 SMTP 发送“死亡原因”邮件与“签到成功”邮件

## 目录结构

```text
.
├── main.py
├── tg_user_keeper/
│   ├── config.py
│   ├── revive.py
│   ├── schedule.py
│   ├── service.py
│   ├── state.py
│   └── telegram_ops.py
├── tests/
├── .env.example
└── tasks.example.json
```

## 安装

```bash
cd "/root/tg/tg-user-keeper"
python3 -m venv ".venv"
source ".venv/bin/activate"
pip install -r "requirements.txt"
```

## 配置

1. 复制环境变量模板：

```bash
cp ".env.example" ".env"
```

2. 如需每日签到，再复制任务模板：

```bash
cp "tasks.example.json" "tasks.json"
```

3. 修改 `.env` 中至少以下字段：

- `TG_USER_API_ID`
- `TG_USER_API_HASH`
- `TG_USER_PHONE`（仅首次 `login` 需要）
- `TG_USER_PROXY_HOST` / `TG_USER_PROXY_PORT`（需要代理连接 Telegram 时）
- `TG_USER_KEEPER_HEALTHCHECK_PEER`（单任务模式）或 `tasks.json` 里的 `healthcheck_tasks`

说明：

- 只跑探活时，`tasks.json` 可以不存在，`sign_tasks` 会视为 `[]`
- 需要每日签到时，再补齐 `TG_USER_KEEPER_TASKS_FILE` 对应文件
- 如需多账号，优先使用 `TG_USER_KEEPER_ACCOUNTS_FILE=./accounts.json`

### 多账号配置

当需要同时守护多个 Telegram 用户号时：

1. 复制模板：

```bash
cp "accounts.example.json" "accounts.json"
```

2. 在 `.env` 中增加：

```bash
TG_USER_KEEPER_ACCOUNTS_FILE=./accounts.json
```

3. 在 `accounts.json` 中为每个账号配置：

- `name`
- `api_id`
- `api_hash`
- `phone`
- `session_path`
- `state_path`
- `notify_peer`（可选，不填时继承 `.env`）

说明：

- 多账号模式下，原有 `TG_USER_API_ID / TG_USER_API_HASH / TG_USER_PHONE` 仍兼容，但会被 `accounts.json` 优先覆盖
- 每个账号必须使用独立 `session_path` 和 `state_path`
- `login` 模式建议配合 `--account <name>` 单独登录指定账号

### Telegram 连接代理变量

- `TG_USER_PROXY_TYPE`：支持 `socks5` / `socks4` / `http`
- `TG_USER_PROXY_HOST`
- `TG_USER_PROXY_PORT`
- `TG_USER_PROXY_RDNS`：默认 `true`
- `TG_USER_PROXY_USERNAME`
- `TG_USER_PROXY_PASSWORD`

### 健康检查与救援关键变量

- `TG_USER_KEEPER_HEALTHCHECK_NAME`：单任务模式下的显示名称
- `TG_USER_KEEPER_HEALTHCHECK_INTERVAL_MINUTES`：默认 `5`
- `TG_USER_KEEPER_HEALTHCHECK_TIMEOUT_SECONDS`：默认 `300`
- `TG_USER_KEEPER_REVIVE_COOLDOWN_SECONDS`：默认 `300`
- `TG_USER_KEEPER_POST_REVIVE_WAIT_SECONDS`：默认 `20`
- `TG_USER_KEEPER_WATCHDOG_SCRIPT`：默认 `/root/tg/tg-invite-bot/scripts/tg_watchdog.sh`

### SMTP 邮件通知变量

- `TG_USER_KEEPER_SMTP_HOST`
- `TG_USER_KEEPER_SMTP_PORT`
- `TG_USER_KEEPER_SMTP_USERNAME`
- `TG_USER_KEEPER_SMTP_PASSWORD`
- `TG_USER_KEEPER_SMTP_FROM`
- `TG_USER_KEEPER_EMAIL_TO`：默认 `3639344085@qq.com`
- `TG_USER_KEEPER_EMAIL_SUBJECT_PREFIX`

说明：

- 探活失败会发送“死亡原因”邮件
- 签到成功会发送成功邮件，包含任务名、目标 bot、命令和 bot 回复内容

### 诊断链路变量

诊断顺序固定为：

1. `TG_USER_KEEPER_OPENCLAW_DIAGNOSE_COMMAND`
2. `TG_USER_KEEPER_CODEX_DIAGNOSE_COMMAND`

默认会自动填入可执行命令模板（支持 `{peer}`、`{reason}` 占位符）：

- OpenClaw：发送 system event
- Codex：执行一次只读诊断

当前实现已经去掉 `bash -lc` 包装，诊断命令会先按参数安全拆分，再直接执行。

你也可以在 `.env` 中覆盖为你自己的命令。

## 运行

首次登录（生成用户会话）：

```bash
python3 "main.py" "login"
```

多账号登录指定账号：

```bash
python3 "main.py" --account "backup" "login"
```

常驻运行：

```bash
python3 "main.py" "run"
```

单次健康检查：

```bash
python3 "main.py" "healthcheck-once"
```

说明：`healthcheck-once` 现在会对所有已配置探活任务各执行一次真正探活，不再伪造失败状态。

单次执行签到+探活：

```bash
python3 "main.py" "sign-once"
```

## 任务文件格式

`tasks.json` 顶层是对象，签到与探活可以并存：

```json
{
  "healthcheck_tasks": [
    {
      "name": "主机器人",
      "peer": "@fakahyzybot",
      "command": "/start",
      "interval_minutes": 5,
      "timeout_seconds": 300,
      "cleanup_messages": true,
      "success_keywords": [],
      "failure_keywords": [],
      "revive_cooldown_seconds": 300,
      "post_revive_wait_seconds": 20,
      "watchdog_script": "/root/tg/tg-invite-bot/scripts/tg_watchdog.sh",
      "watchdog_process_keyword": "/root/tg/tg-invite-bot/scripts/tg_watchdog.sh",
      "bot_process_keyword": "/root/tg/tg-invite-bot/bot.py"
    },
    {
      "name": "接码机器人",
      "peer": "@your_apicc_bot",
      "command": "/start",
      "interval_minutes": 5,
      "timeout_seconds": 300,
      "cleanup_messages": true,
      "success_keywords": [],
      "failure_keywords": [],
      "revive_cooldown_seconds": 300,
      "post_revive_wait_seconds": 20,
      "watchdog_script": "/root/tg/tg-invite-bot/scripts/apicc_watchdog.sh",
      "watchdog_process_keyword": "/root/tg/tg-invite-bot/scripts/apicc_watchdog.sh",
      "bot_process_keyword": "/root/tg/tg-invite-bot/apicc_bot.py"
    }
  ],
  "sign_tasks": [
    {
      "name": "每日签到",
      "peer": "@some_checkin_bot",
      "command": "/checkin",
      "time": "09:00",
      "timeout_seconds": 30,
      "retry_interval_minutes": 120,
      "success_keywords": ["成功", "已签到"],
      "failure_keywords": ["异常", "错误", "请先注册"],
      "cleanup_messages": true
    }
  ]
}
```

## 测试

```bash
cd "/root/tg/tg-user-keeper"
python3 -m unittest discover -s "tests" -p "test_*.py"
```

## 说明

- 本服务只负责“用户号探活 + 自动救援调度”，不改动 `tg-invite-bot` 主项目代码。
- 状态文件默认在 `./data/state.json`。
- `tg_watchdog.sh` 现在支持通过环境变量覆盖 `BOT_SCRIPT / LOG / PID / HEARTBEAT_FILE`；`apicc_watchdog.sh` 是接码机器人专用包装脚本。
- 若连续失败，请优先检查：
  - Telegram 用户会话是否过期
  - `healthcheck_tasks` / `TG_USER_KEEPER_HEALTHCHECK_PEER` 是否正确
  - 对应任务的 `watchdog_script` 是否可执行
