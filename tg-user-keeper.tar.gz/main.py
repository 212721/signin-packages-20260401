from __future__ import annotations

import argparse
import asyncio
import logging
from datetime import datetime

from telethon import TelegramClient

from tg_user_keeper.config import AppConfig, TelegramAccountConfig, load_config
from tg_user_keeper.mailer import SmtpAlertMailer
from tg_user_keeper.revive import WatchdogReviver
from tg_user_keeper.service import KeeperService
from tg_user_keeper.state import JsonStateStore
from tg_user_keeper.telegram_ops import TelegramBotInteractor


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="TG 用户号签到与 tgbot 探活守护")
    parser.add_argument("--env-file", default="", help="指定 .env 文件路径")
    parser.add_argument("--account", default="", help="指定账号名；多账号 login 时必填")
    parser.add_argument("command", choices=["login", "run", "healthcheck-once", "sign-once"], help="执行模式")
    return parser


async def async_main() -> int:
    args = build_parser().parse_args()
    config = load_config(args.env_file or None)
    _configure_logging()
    accounts = _select_accounts(config, args.account.strip())
    if args.command == "login":
        if len(accounts) != 1:
            raise SystemExit("多账号登录请使用 --account 指定账号名")
        ok = await _run_for_account(config.for_account(accounts[0]), command=args.command, account_name=accounts[0].name)
        return 0 if ok else 1
    results = await asyncio.gather(
        *(
            _run_for_account(config.for_account(account), command=args.command, account_name=account.name)
            for account in accounts
        )
    )
    return 0 if all(results) else 1


def _select_accounts(config: AppConfig, account_name: str) -> list[TelegramAccountConfig]:
    accounts = list(config.accounts) or [config.primary_account()]
    if not account_name:
        return accounts
    selected = [item for item in accounts if item.name == account_name]
    if not selected:
        available = ", ".join(item.name for item in accounts)
        raise SystemExit(f"未找到账号 {account_name}；可用账号：{available}")
    return selected


async def _run_for_account(config: AppConfig, *, command: str, account_name: str) -> bool:
    client = TelegramClient(
        config.session_path,
        config.api_id,
        config.api_hash,
        proxy=config.telegram_proxy,
    )
    try:
        async with client:
            interactor = TelegramBotInteractor(client, notify_peer=config.notify_peer)
            if command == "login":
                await interactor.interactive_login(config.phone)
                print(f"[{account_name}] 登录成功，session 已保存。")
                return True
            await interactor.ensure_authorized()
            state_store = JsonStateStore(config.state_path)
            reviver = WatchdogReviver(config.revive)
            mailer = None if config.email_alert is None else SmtpAlertMailer(config.email_alert)
            service = KeeperService(
                config,
                state_store=state_store,
                interactor=interactor,
                reviver=reviver,
                mailer=mailer,
            )
            if command == "run":
                logging.info("account started: %s", account_name)
                await service.run_forever()
                return True
            if command == "healthcheck-once":
                await run_healthcheck_once(config, service, state_store)
                logging.info("healthcheck finished: %s", account_name)
                return True
            if command == "sign-once":
                await service.run_once(datetime.now(config.timezone))
                logging.info("sign run finished: %s", account_name)
                return True
    except Exception:
        logging.exception("account execution failed: %s", account_name)
        return False
    return False


async def run_healthcheck_once(config: AppConfig, service: KeeperService, state_store: JsonStateStore) -> None:
    del state_store
    if not config.healthchecks and config.healthcheck is None:
        raise SystemExit("未配置健康检查任务，无法执行 healthcheck-once")
    await service.run_healthcheck_once(datetime.now(config.timezone))


def _configure_logging() -> None:
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(message)s",
    )


def main() -> None:
    raise SystemExit(asyncio.run(async_main()))


if __name__ == "__main__":
    main()
