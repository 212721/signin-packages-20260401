import asyncio
import tempfile
import unittest
from datetime import datetime
from unittest import mock
from zoneinfo import ZoneInfo

from tg_user_keeper.config import AppConfig, HealthCheckConfig, ReviveConfig, SignTaskConfig
from tg_user_keeper.revive import DiagnosisResult, ReviveResult
from tg_user_keeper.service import KeeperService
from tg_user_keeper.state import JsonStateStore
from tg_user_keeper.telegram_ops import InteractionResult


class _FakeInteractor:
    def __init__(self, results):
        self._results = list(results)
        self.notifications = []

    async def send_command_and_wait(self, **_kwargs):
        return self._results.pop(0)

    async def notify(self, text: str) -> None:
        self.notifications.append(text)


class _FakeReviver:
    def __init__(self, result: ReviveResult):
        self.result = result
        self.calls = []

    def revive(self, **kwargs):
        self.calls.append(kwargs)
        return self.result


class _FakeMailer:
    enabled = True

    def __init__(self):
        self.calls = []
        self.sign_success_calls = []

    def send_death_reason(self, **kwargs):
        self.calls.append(kwargs)
        return True

    def send_sign_success(self, **kwargs):
        self.sign_success_calls.append(kwargs)
        return True


class _ExplodingReviver:
    def revive(self, **_kwargs):
        raise FileNotFoundError("missing watchdog script")


class _ConcurrentInteractor:
    def __init__(self):
        self.active = 0
        self.max_active = 0
        self.notifications = []

    async def send_command_and_wait(self, **_kwargs):
        self.active += 1
        self.max_active = max(self.max_active, self.active)
        await asyncio.sleep(0.05)
        self.active -= 1
        return InteractionResult(ok=True, response_text="ok", error_text="")

    async def notify(self, text: str) -> None:
        self.notifications.append(text)


class ServiceTests(unittest.IsolatedAsyncioTestCase):
    async def test_run_once_sends_sign_success_email(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            config = AppConfig(
                api_id=1,
                api_hash="hash",
                phone="",
                session_path=str(tmpdir + "/session"),
                timezone_name="Asia/Shanghai",
                timezone=ZoneInfo("Asia/Shanghai"),
                state_path=str(tmpdir + "/state.json"),
                tasks_file=str(tmpdir + "/tasks.json"),
                poll_interval_seconds=30,
                notify_peer="me",
                sign_tasks=[
                    SignTaskConfig(
                        name="每日签到 HomeSGKBOT",
                        peer="@HomeSGKBOT",
                        command="/sign",
                        run_at=datetime(2026, 3, 24, 9, 0, 0).time(),
                        timeout_seconds=30,
                        retry_interval_minutes=120,
                        success_keywords=[],
                        cleanup_messages=True,
                    )
                ],
                healthcheck=None,
                revive=ReviveConfig(
                    watchdog_script="/root/tg/tg-invite-bot/scripts/tg_watchdog.sh",
                    watchdog_process_keyword="tg_watchdog.sh",
                    bot_process_keyword="bot.py",
                    kill_grace_seconds=1,
                    diagnosis_timeout_seconds=30,
                    openclaw_diagnose_command="openclaw diagnose {peer} {reason}",
                    codex_diagnose_command="codex diagnose {peer} {reason}",
                ),
            )
            interactor = _FakeInteractor(
                [
                    InteractionResult(ok=True, response_text="签到成功", error_text=""),
                ]
            )
            mailer = _FakeMailer()
            service = KeeperService(
                config,
                state_store=JsonStateStore(config.state_path),
                interactor=interactor,
                reviver=_FakeReviver(
                    ReviveResult(
                        triggered=False,
                        watchdog_started=False,
                        watchdog_ready=True,
                        killed_pids=[],
                        reason="",
                        diagnosis=DiagnosisResult(
                            attempted=False,
                            provider="none",
                            ok=False,
                            command="",
                            exit_code=None,
                            summary="",
                        ),
                    )
                ),
                mailer=mailer,
            )

            async def _run_inline(func, /, *args, **kwargs):
                return func(*args, **kwargs)

            with mock.patch("tg_user_keeper.service.asyncio.to_thread", new=_run_inline):
                await service.run_once(datetime(2026, 3, 24, 9, 0, 1, tzinfo=config.timezone))

        self.assertEqual(1, len(mailer.sign_success_calls))
        self.assertEqual("每日签到 HomeSGKBOT", mailer.sign_success_calls[0]["task_name"])
        self.assertEqual("@HomeSGKBOT", mailer.sign_success_calls[0]["peer"])
        self.assertEqual("/sign", mailer.sign_success_calls[0]["command"])
        self.assertEqual("签到成功", mailer.sign_success_calls[0]["response_text"])

    async def test_run_healthcheck_once_executes_without_interval_gate(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            config = AppConfig(
                api_id=1,
                api_hash="hash",
                phone="",
                session_path=str(tmpdir + "/session"),
                timezone_name="Asia/Shanghai",
                timezone=ZoneInfo("Asia/Shanghai"),
                state_path=str(tmpdir + "/state.json"),
                tasks_file=str(tmpdir + "/tasks.json"),
                poll_interval_seconds=30,
                notify_peer="me",
                sign_tasks=[],
                healthcheck=HealthCheckConfig(
                    peer="@fakahyzybot",
                    command="/start",
                    interval_minutes=5,
                    timeout_seconds=300,
                    success_keywords=[],
                    cleanup_messages=True,
                    revive_cooldown_seconds=300,
                    post_revive_wait_seconds=5,
                    name="主机器人",
                    state_key="main_bot",
                ),
                revive=ReviveConfig(
                    watchdog_script="/root/tg/tg-invite-bot/scripts/tg_watchdog.sh",
                    watchdog_process_keyword="tg_watchdog.sh",
                    bot_process_keyword="bot.py",
                    kill_grace_seconds=1,
                    diagnosis_timeout_seconds=30,
                    openclaw_diagnose_command="openclaw diagnose {peer} {reason}",
                    codex_diagnose_command="codex diagnose {peer} {reason}",
                ),
            )
            state_store = JsonStateStore(config.state_path)
            state_store.mark_health_success(
                when=datetime(2026, 3, 24, 10, 0, 0, tzinfo=config.timezone),
                response_text="ok",
            )
            interactor = _FakeInteractor(
                [
                    InteractionResult(ok=False, response_text="", error_text="timeout"),
                ]
            )
            reviver = _FakeReviver(
                ReviveResult(
                    triggered=False,
                    watchdog_started=False,
                    watchdog_ready=True,
                    killed_pids=[],
                    reason="timeout",
                    diagnosis=DiagnosisResult(
                        attempted=False,
                        provider="none",
                        ok=False,
                        command="",
                        exit_code=None,
                        summary="冷却时间内跳过诊断与复活",
                    ),
                )
            )
            service = KeeperService(
                config,
                state_store=state_store,
                interactor=interactor,
                reviver=reviver,
            )
            await service.run_healthcheck_once(datetime(2026, 3, 24, 10, 0, 1, tzinfo=config.timezone))

        self.assertEqual(1, len(reviver.calls))
        self.assertTrue(interactor.notifications)

    async def test_run_healthcheck_once_supports_multiple_tasks_and_sends_email(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            healthchecks = (
                HealthCheckConfig(
                    peer="@mainbot",
                    command="/start",
                    interval_minutes=5,
                    timeout_seconds=300,
                    success_keywords=[],
                    cleanup_messages=True,
                    revive_cooldown_seconds=300,
                    post_revive_wait_seconds=5,
                    name="主机器人",
                    state_key="main_bot",
                ),
                HealthCheckConfig(
                    peer="@apiccbot",
                    command="/start",
                    interval_minutes=5,
                    timeout_seconds=300,
                    success_keywords=[],
                    cleanup_messages=True,
                    revive_cooldown_seconds=300,
                    post_revive_wait_seconds=5,
                    name="接码机器人",
                    state_key="apicc_bot",
                ),
            )
            config = AppConfig(
                api_id=1,
                api_hash="hash",
                phone="",
                session_path=str(tmpdir + "/session"),
                timezone_name="Asia/Shanghai",
                timezone=ZoneInfo("Asia/Shanghai"),
                state_path=str(tmpdir + "/state.json"),
                tasks_file=str(tmpdir + "/tasks.json"),
                poll_interval_seconds=30,
                notify_peer="me",
                sign_tasks=[],
                healthcheck=healthchecks[0],
                revive=ReviveConfig(
                    watchdog_script="/root/tg/tg-invite-bot/scripts/tg_watchdog.sh",
                    watchdog_process_keyword="tg_watchdog.sh",
                    bot_process_keyword="bot.py",
                    kill_grace_seconds=1,
                    diagnosis_timeout_seconds=30,
                    openclaw_diagnose_command="openclaw diagnose {peer} {reason}",
                    codex_diagnose_command="codex diagnose {peer} {reason}",
                ),
                healthchecks=healthchecks,
            )
            state_store = JsonStateStore(config.state_path)
            interactor = _FakeInteractor(
                [
                    InteractionResult(ok=True, response_text="ok", error_text=""),
                    InteractionResult(ok=False, response_text="", error_text="消息发送失败：network"),
                ]
            )
            reviver = _FakeReviver(
                ReviveResult(
                    triggered=False,
                    watchdog_started=False,
                    watchdog_ready=True,
                    killed_pids=[],
                    reason="消息发送失败：network",
                    diagnosis=DiagnosisResult(
                        attempted=False,
                        provider="none",
                        ok=False,
                        command="",
                        exit_code=None,
                        summary="冷却时间内跳过诊断与复活",
                    ),
                )
            )
            mailer = _FakeMailer()
            service = KeeperService(
                config,
                state_store=state_store,
                interactor=interactor,
                reviver=reviver,
                mailer=mailer,
            )
            async def _run_inline(func, /, *args, **kwargs):
                return func(*args, **kwargs)

            with mock.patch("tg_user_keeper.service.asyncio.to_thread", new=_run_inline):
                await service.run_healthcheck_once(datetime(2026, 3, 24, 10, 0, 1, tzinfo=config.timezone))

        self.assertEqual(1, len(mailer.calls))
        self.assertEqual("接码机器人", mailer.calls[0]["task_name"])
        self.assertEqual("消息发送失败：network", mailer.calls[0]["failure_reason"])

    async def test_run_healthcheck_once_executes_multiple_targets_concurrently(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            healthchecks = (
                HealthCheckConfig(
                    peer="@mainbot",
                    command="/start",
                    interval_minutes=5,
                    timeout_seconds=30,
                    success_keywords=[],
                    cleanup_messages=True,
                    revive_cooldown_seconds=300,
                    post_revive_wait_seconds=5,
                    name="主机器人",
                    state_key="main_bot",
                ),
                HealthCheckConfig(
                    peer="@apiccbot",
                    command="/start",
                    interval_minutes=5,
                    timeout_seconds=30,
                    success_keywords=[],
                    cleanup_messages=True,
                    revive_cooldown_seconds=300,
                    post_revive_wait_seconds=5,
                    name="接码机器人",
                    state_key="apicc_bot",
                ),
            )
            config = AppConfig(
                api_id=1,
                api_hash="hash",
                phone="",
                session_path=str(tmpdir + "/session"),
                timezone_name="Asia/Shanghai",
                timezone=ZoneInfo("Asia/Shanghai"),
                state_path=str(tmpdir + "/state.json"),
                tasks_file=str(tmpdir + "/tasks.json"),
                poll_interval_seconds=30,
                notify_peer="me",
                sign_tasks=[],
                healthcheck=healthchecks[0],
                revive=ReviveConfig(
                    watchdog_script="/root/tg/tg-invite-bot/scripts/tg_watchdog.sh",
                    watchdog_process_keyword="tg_watchdog.sh",
                    bot_process_keyword="bot.py",
                    kill_grace_seconds=1,
                    diagnosis_timeout_seconds=30,
                    openclaw_diagnose_command="openclaw diagnose {peer} {reason}",
                    codex_diagnose_command="codex diagnose {peer} {reason}",
                ),
                healthchecks=healthchecks,
            )
            interactor = _ConcurrentInteractor()
            service = KeeperService(
                config,
                state_store=JsonStateStore(config.state_path),
                interactor=interactor,
                reviver=_FakeReviver(
                    ReviveResult(
                        triggered=False,
                        watchdog_started=False,
                        watchdog_ready=True,
                        killed_pids=[],
                        reason="",
                        diagnosis=DiagnosisResult(
                            attempted=False,
                            provider="none",
                            ok=False,
                            command="",
                            exit_code=None,
                            summary="",
                        ),
                    )
                ),
            )
            await service.run_healthcheck_once(datetime(2026, 3, 24, 10, 0, 1, tzinfo=config.timezone))

        self.assertGreaterEqual(interactor.max_active, 2)

    async def test_run_healthcheck_once_survives_reviver_exception(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            config = AppConfig(
                api_id=1,
                api_hash="hash",
                phone="",
                session_path=str(tmpdir + "/session"),
                timezone_name="Asia/Shanghai",
                timezone=ZoneInfo("Asia/Shanghai"),
                state_path=str(tmpdir + "/state.json"),
                tasks_file=str(tmpdir + "/tasks.json"),
                poll_interval_seconds=30,
                notify_peer="me",
                sign_tasks=[],
                healthcheck=HealthCheckConfig(
                    peer="@fakahyzybot",
                    command="/start",
                    interval_minutes=5,
                    timeout_seconds=30,
                    success_keywords=[],
                    cleanup_messages=True,
                    revive_cooldown_seconds=300,
                    post_revive_wait_seconds=5,
                    name="主机器人",
                    state_key="main_bot",
                ),
                revive=ReviveConfig(
                    watchdog_script="/missing.sh",
                    watchdog_process_keyword="tg_watchdog.sh",
                    bot_process_keyword="bot.py",
                    kill_grace_seconds=1,
                    diagnosis_timeout_seconds=30,
                    openclaw_diagnose_command="openclaw diagnose {peer} {reason}",
                    codex_diagnose_command="codex diagnose {peer} {reason}",
                ),
            )
            interactor = _FakeInteractor(
                [
                    InteractionResult(ok=False, response_text="", error_text="timeout"),
                ]
            )
            service = KeeperService(
                config,
                state_store=JsonStateStore(config.state_path),
                interactor=interactor,
                reviver=_ExplodingReviver(),
            )
            await service.run_healthcheck_once(datetime(2026, 3, 24, 10, 0, 1, tzinfo=config.timezone))

        self.assertTrue(interactor.notifications)
        self.assertIn("复活流程异常", interactor.notifications[0])


if __name__ == "__main__":
    unittest.main()
