import tempfile
import unittest
from pathlib import Path
from unittest import mock

from tg_user_keeper.config import load_config


class ConfigTests(unittest.TestCase):
    def test_load_config_allows_missing_sign_tasks_file(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            session_path = Path(tmpdir) / "session"
            state_path = Path(tmpdir) / "state.json"
            env = {
                "TG_USER_API_ID": "1000",
                "TG_USER_API_HASH": "hash",
                "TG_USER_PHONE": "+10086",
                "TG_USER_SESSION_PATH": str(session_path),
                "TG_USER_KEEPER_STATE_PATH": str(state_path),
                "TG_USER_KEEPER_TASKS_FILE": str(Path(tmpdir) / "missing.json"),
                "TG_USER_KEEPER_HEALTHCHECK_PEER": "@fakahyzybot",
            }
            with mock.patch("tg_user_keeper.config.load_dotenv", return_value=False):
                with mock.patch.dict("os.environ", env, clear=True):
                    config = load_config(strict_sign_tasks=False)
        self.assertEqual([], config.sign_tasks)

    def test_load_config_reads_healthcheck_tasks_and_email_alert(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            tasks_path = Path(tmpdir) / "tasks.json"
            tasks_path.write_text(
                """
                {
                  "healthcheck_tasks": [
                    {
                      "name": "主机器人",
                      "peer": "@mainbot",
                      "command": "/start",
                      "interval_minutes": 5,
                      "timeout_seconds": 60,
                      "bot_process_keyword": "/root/tg/tg-invite-bot/bot.py"
                    },
                    {
                      "name": "接码机器人",
                      "peer": "@apiccbot",
                      "command": "/start",
                      "interval_minutes": 5,
                      "timeout_seconds": 60,
                      "bot_process_keyword": "/root/tg/tg-invite-bot/apicc_bot.py"
                    }
                  ]
                }
                """.strip(),
                encoding="utf-8",
            )
            env = {
                "TG_USER_API_ID": "1000",
                "TG_USER_API_HASH": "hash",
                "TG_USER_KEEPER_TASKS_FILE": str(tasks_path),
                "TG_USER_KEEPER_SMTP_HOST": "smtp.example.com",
                "TG_USER_KEEPER_SMTP_FROM": "robot@example.com",
                "TG_USER_KEEPER_EMAIL_TO": "3639344085@qq.com,ops@example.com",
            }
            with mock.patch("tg_user_keeper.config.load_dotenv", return_value=False):
                with mock.patch.dict("os.environ", env, clear=True):
                    config = load_config(strict_sign_tasks=False)
        self.assertEqual(2, len(config.healthchecks))
        self.assertEqual("主机器人", config.healthchecks[0].name)
        self.assertEqual("接码机器人", config.healthchecks[1].name)
        self.assertIsNotNone(config.email_alert)
        assert config.email_alert is not None
        self.assertEqual(("3639344085@qq.com", "ops@example.com"), config.email_alert.to_addrs)

    def test_load_config_reads_sign_failure_keywords_and_proxy(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            tasks_path = Path(tmpdir) / "tasks.json"
            tasks_path.write_text(
                """
                {
                  "sign_tasks": [
                    {
                      "name": "每日签到",
                      "peer": "@checkin_bot",
                      "command": "/checkin",
                      "success_keywords": ["签到成功"],
                      "failure_keywords": ["内部错误", "请先注册"]
                    }
                  ]
                }
                """.strip(),
                encoding="utf-8",
            )
            env = {
                "TG_USER_API_ID": "1000",
                "TG_USER_API_HASH": "hash",
                "TG_USER_KEEPER_TASKS_FILE": str(tasks_path),
                "TG_USER_PROXY_TYPE": "http",
                "TG_USER_PROXY_HOST": "127.0.0.1",
                "TG_USER_PROXY_PORT": "7890",
                "TG_USER_PROXY_RDNS": "false",
                "TG_USER_PROXY_USERNAME": "alice",
                "TG_USER_PROXY_PASSWORD": "secret",
            }
            with mock.patch("tg_user_keeper.config.load_dotenv", return_value=False):
                with mock.patch.dict("os.environ", env, clear=True):
                    config = load_config(strict_sign_tasks=False)
        self.assertEqual(1, len(config.sign_tasks))
        self.assertEqual(["签到成功"], config.sign_tasks[0].success_keywords)
        self.assertEqual(["内部错误", "请先注册"], config.sign_tasks[0].failure_keywords)
        self.assertEqual(("http", "127.0.0.1", 7890, False, "alice", "secret"), config.telegram_proxy)

    def test_load_config_does_not_use_hardcoded_email_recipient(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            env = {
                "TG_USER_API_ID": "1000",
                "TG_USER_API_HASH": "hash",
                "TG_USER_KEEPER_TASKS_FILE": str(Path(tmpdir) / "missing.json"),
                "TG_USER_KEEPER_HEALTHCHECK_PEER": "@fakahyzybot",
                "TG_USER_KEEPER_SMTP_HOST": "smtp.example.com",
                "TG_USER_KEEPER_SMTP_FROM": "robot@example.com",
            }
            with mock.patch("tg_user_keeper.config.load_dotenv", return_value=False):
                with mock.patch.dict("os.environ", env, clear=True):
                    config = load_config(strict_sign_tasks=False)
        assert config.email_alert is not None
        self.assertEqual((), config.email_alert.to_addrs)

    def test_load_config_reads_multiple_accounts_file(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            accounts_path = Path(tmpdir) / "accounts.json"
            accounts_path.write_text(
                """
                {
                  "accounts": [
                    {
                      "name": "main",
                      "api_id": 1000,
                      "api_hash": "hash-main",
                      "phone": "+10086",
                      "session_path": "./data/userkeeper",
                      "state_path": "./data/state.json"
                    },
                    {
                      "name": "backup",
                      "api_id": 2000,
                      "api_hash": "hash-backup",
                      "phone": "+10010",
                      "session_path": "./data/userkeeper_backup",
                      "state_path": "./data/state_backup.json",
                      "notify_peer": "self"
                    }
                  ]
                }
                """.strip(),
                encoding="utf-8",
            )
            env = {
                "TG_USER_KEEPER_ACCOUNTS_FILE": str(accounts_path),
                "TG_USER_KEEPER_NOTIFY_PEER": "me",
                "TG_USER_KEEPER_TASKS_FILE": str(Path(tmpdir) / "missing.json"),
            }
            with mock.patch("tg_user_keeper.config.load_dotenv", return_value=False):
                with mock.patch.dict("os.environ", env, clear=True):
                    config = load_config(strict_sign_tasks=False)
        self.assertEqual(2, len(config.accounts))
        self.assertEqual("main", config.accounts[0].name)
        self.assertEqual(1000, config.api_id)
        self.assertTrue(config.session_path.endswith("data/userkeeper"))
        self.assertEqual("backup", config.accounts[1].name)
        self.assertEqual("self", config.accounts[1].notify_peer)
        backup_config = config.for_account(config.accounts[1])
        self.assertEqual(2000, backup_config.api_id)
        self.assertTrue(backup_config.session_path.endswith("data/userkeeper_backup"))
        self.assertTrue(backup_config.state_path.endswith("data/state_backup.json"))


if __name__ == "__main__":
    unittest.main()
