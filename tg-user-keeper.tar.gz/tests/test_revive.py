import datetime
import unittest
import shlex

from tg_user_keeper.config import ReviveConfig
from tg_user_keeper.revive import ProcessMatcher, WatchdogReviver


class ProcessMatcherTests(unittest.TestCase):
    def test_match_extracts_pid_and_args(self) -> None:
        ps_output = (
            "647 /usr/bin/bash /root/tg/tg-invite-bot/scripts/tg_watchdog.sh\n"
            "475029 /root/tg/tg-invite-bot/.venv_bot/bin/python /root/tg/tg-invite-bot/bot.py\n"
        )
        matches = ProcessMatcher("bot.py").match(ps_output)
        self.assertEqual(1, len(matches))
        self.assertEqual(475029, matches[0].pid)


class WatchdogReviverTests(unittest.TestCase):
    def _build_config(self) -> ReviveConfig:
        return ReviveConfig(
            watchdog_script="/root/tg/tg-invite-bot/scripts/tg_watchdog.sh",
            watchdog_process_keyword="tg_watchdog.sh",
            bot_process_keyword="bot.py",
            kill_grace_seconds=0,
            diagnosis_timeout_seconds=30,
            openclaw_diagnose_command='openclaw diagnose --peer "{peer}" --reason "{reason}"',
            codex_diagnose_command='codex diagnose --peer "{peer}"',
        )

    def test_revive_runs_openclaw_then_fallback_codex(self) -> None:
        ps_outputs = [
            "",
            "647 /usr/bin/bash /root/tg/tg-invite-bot/scripts/tg_watchdog.sh\n",
            "111 /root/tg/tg-invite-bot/bot.py\n",
            "",
        ]
        started_scripts: list[str] = []
        killed_signals: list[tuple[int, int]] = []
        diag_commands: list[str] = []

        def ps_reader() -> str:
            if not ps_outputs:
                return ""
            return ps_outputs.pop(0)

        def process_starter(script: str) -> None:
            started_scripts.append(script)

        def command_runner(command: list[str], _timeout_seconds: int) -> tuple[int, str, str]:
            rendered = shlex.join(command)
            diag_commands.append(rendered)
            if command[:1] == ["openclaw"]:
                return (1, "", "openclaw failed")
            return (0, "codex ok", "")

        def killer(pid: int, sig: int) -> None:
            killed_signals.append((pid, sig))

        reviver = WatchdogReviver(
            self._build_config(),
            ps_reader=ps_reader,
            process_starter=process_starter,
            sleeper=lambda _seconds: None,
            command_runner=command_runner,
            killer=killer,
        )
        result = reviver.revive(
            peer="@fakahyzybot",
            reason="5分钟无回复",
            last_revive_at=None,
            now=datetime.datetime(2026, 3, 24, 10, 0, 0),
            cooldown_seconds=300,
        )

        self.assertTrue(result.triggered)
        self.assertTrue(result.watchdog_started)
        self.assertEqual([111], result.killed_pids)
        self.assertTrue(result.diagnosis.attempted)
        self.assertEqual("codex", result.diagnosis.provider)
        self.assertTrue(result.diagnosis.ok)
        self.assertIn("openclaw", diag_commands[0])
        self.assertIn("codex", diag_commands[1])
        self.assertEqual(1, len(started_scripts))
        self.assertTrue(killed_signals)

    def test_revive_respects_cooldown_and_skips_actions(self) -> None:
        started_scripts: list[str] = []
        diag_commands: list[str] = []
        reviver = WatchdogReviver(
            self._build_config(),
            ps_reader=lambda: "",
            process_starter=lambda script: started_scripts.append(script),
            sleeper=lambda _seconds: None,
            command_runner=lambda command, _timeout: diag_commands.append(shlex.join(command)) or (0, "ok", ""),
            killer=lambda _pid, _sig: None,
        )
        now = datetime.datetime(2026, 3, 24, 10, 0, 0)
        result = reviver.revive(
            peer="@fakahyzybot",
            reason="timeout",
            last_revive_at=now,
            now=now,
            cooldown_seconds=300,
        )
        self.assertFalse(result.triggered)
        self.assertFalse(result.diagnosis.attempted)
        self.assertFalse(started_scripts)
        self.assertFalse(diag_commands)

    def test_revive_does_not_kill_bot_when_watchdog_not_ready(self) -> None:
        ps_outputs = [
            "",
            "",
        ]
        killed_signals: list[tuple[int, int]] = []

        def ps_reader() -> str:
            if not ps_outputs:
                return ""
            return ps_outputs.pop(0)

        reviver = WatchdogReviver(
            self._build_config(),
            ps_reader=ps_reader,
            process_starter=lambda _script: None,
            sleeper=lambda _seconds: None,
            command_runner=lambda _command, _timeout: (0, "ok", ""),
            killer=lambda pid, sig: killed_signals.append((pid, sig)),
        )
        result = reviver.revive(
            peer="@fakahyzybot",
            reason="timeout",
            last_revive_at=None,
            now=datetime.datetime(2026, 3, 24, 10, 0, 0),
            cooldown_seconds=300,
        )
        self.assertTrue(result.triggered)
        self.assertFalse(result.watchdog_started)
        self.assertFalse(result.watchdog_ready)
        self.assertEqual([], result.killed_pids)
        self.assertEqual([], killed_signals)

    def test_revive_returns_watchdog_error_when_starter_crashes(self) -> None:
        reviver = WatchdogReviver(
            self._build_config(),
            ps_reader=lambda: "",
            process_starter=lambda _script: (_ for _ in ()).throw(FileNotFoundError("missing watchdog")),
            sleeper=lambda _seconds: None,
            command_runner=lambda _command, _timeout: (0, "ok", ""),
            killer=lambda _pid, _sig: None,
        )
        result = reviver.revive(
            peer="@fakahyzybot",
            reason="timeout",
            last_revive_at=None,
            now=datetime.datetime(2026, 3, 24, 10, 0, 0),
            cooldown_seconds=300,
        )
        self.assertTrue(result.triggered)
        self.assertFalse(result.watchdog_ready)
        self.assertIn("watchdog 启动失败", result.watchdog_error)
