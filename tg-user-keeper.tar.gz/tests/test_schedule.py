import datetime
import unittest

from tg_user_keeper import schedule


class ScheduleDecisionTests(unittest.TestCase):
    def test_interval_check_runs_when_due(self):
        now = datetime.datetime(2026, 3, 22, 10, 0)
        last_check = datetime.datetime(2026, 3, 22, 8, 0)
        self.assertTrue(
            schedule.should_run_interval_check(now, last_check, interval_minutes=60)
        )

    def test_interval_check_skips_when_recent(self):
        now = datetime.datetime(2026, 3, 22, 10, 5)
        last_check = datetime.datetime(2026, 3, 22, 10, 0)
        self.assertFalse(
            schedule.should_run_interval_check(now, last_check, interval_minutes=15)
        )

    def test_daily_task_runs_after_midnight_new_day(self):
        now = datetime.datetime(2026, 3, 22, 0, 30)
        last_success = "2026-03-21"
        last_attempt = datetime.datetime(2026, 3, 21, 23, 55)
        task_time = datetime.time(0, 0)
        self.assertTrue(
            schedule.should_run_daily_task(
                now, task_time, last_success, last_attempt, retry_interval_minutes=30
            )
        )

    def test_daily_task_respects_retry_interval(self):
        now = datetime.datetime(2026, 3, 22, 0, 15)
        last_success = "2026-03-21"
        last_attempt = datetime.datetime(2026, 3, 22, 0, 0)
        task_time = datetime.time(0, 0)
        self.assertFalse(
            schedule.should_run_daily_task(
                now, task_time, last_success, last_attempt, retry_interval_minutes=30
            )
        )

    def test_daily_task_skips_when_already_success_today(self):
        now = datetime.datetime(2026, 3, 22, 9, 1)
        task_time = datetime.time(9, 0)
        self.assertFalse(
            schedule.should_run_daily_task(
                now,
                task_time,
                "2026-03-22",
                datetime.datetime(2026, 3, 22, 9, 0),
                retry_interval_minutes=30,
            )
        )
