import types
import unittest

from tg_user_keeper.telegram_ops import TelegramBotInteractor


class TelegramOpsTests(unittest.TestCase):
    def test_evaluate_response_status_matches_success_keyword(self) -> None:
        ok, error = TelegramBotInteractor._evaluate_response_status(
            "今日签到成功，积分+1",
            success_keywords=["签到成功"],
            failure_keywords=["内部错误"],
        )
        self.assertTrue(ok)
        self.assertEqual("", error)

    def test_evaluate_response_status_rejects_failure_keyword_first(self) -> None:
        ok, error = TelegramBotInteractor._evaluate_response_status(
            "机器人内部错误，请联系人工客服！",
            success_keywords=["成功"],
            failure_keywords=["内部错误", "联系客服"],
        )
        self.assertFalse(ok)
        self.assertIn("失败关键词", error)

    def test_evaluate_response_status_rejects_when_success_keyword_missing(self) -> None:
        ok, error = TelegramBotInteractor._evaluate_response_status(
            "请先使用 /start 注册机器人在使用！",
            success_keywords=["签到成功"],
            failure_keywords=[],
        )
        self.assertFalse(ok)
        self.assertIn("未命中成功关键词", error)


class _FakeConversation:
    def __init__(self, responses: list[object]):
        self._responses = list(responses)
        self.sent_messages: list[str] = []

    async def __aenter__(self):
        return self

    async def __aexit__(self, exc_type, exc, tb):
        return False

    async def send_message(self, text: str):
        self.sent_messages.append(text)
        return types.SimpleNamespace(id=101)

    async def get_response(self):
        if not self._responses:
            raise AssertionError("no response queued")
        return self._responses.pop(0)


class _FakeClient:
    def __init__(self, responses: list[object]):
        self._conversation = _FakeConversation(responses)
        self.deleted: list[tuple[str, list[int]]] = []

    def conversation(self, _peer: str, timeout: int):
        assert timeout > 0
        return self._conversation

    async def delete_messages(self, peer: str, message_ids: list[int]) -> None:
        self.deleted.append((peer, list(message_ids)))


class TelegramOpsAsyncTests(unittest.IsolatedAsyncioTestCase):
    async def test_send_command_and_wait_accepts_follow_up_success(self) -> None:
        client = _FakeClient(
            [
                types.SimpleNamespace(id=201, raw_text="✅ 正在签到,请稍后..."),
                types.SimpleNamespace(id=202, raw_text="🌟 您已经签到过了！"),
            ]
        )
        interactor = TelegramBotInteractor(client)

        result = await interactor.send_command_and_wait(
            peer="@demo_bot",
            command="/sign",
            timeout_seconds=5,
            success_keywords=["签到成功", "签到过了", "已签到"],
            failure_keywords=["错误", "请先注册"],
            cleanup_messages=True,
        )

        self.assertTrue(result.ok)
        self.assertEqual("🌟 您已经签到过了！", result.response_text)
        self.assertEqual(202, result.response_message_id)
        self.assertEqual([("@demo_bot", [101, 201, 202])], client.deleted)

    async def test_send_command_and_wait_accepts_multiple_follow_up_messages(self) -> None:
        client = _FakeClient(
            [
                types.SimpleNamespace(id=201, raw_text="🔄 正在为您续期卡密，请稍候..."),
                types.SimpleNamespace(id=202, raw_text="🔄 正在排队处理中，请稍候..."),
                types.SimpleNamespace(id=203, raw_text="✅ 续期成功，卡密有效期已更新"),
            ]
        )
        interactor = TelegramBotInteractor(client)

        result = await interactor.send_command_and_wait(
            peer="@speed_bot",
            command="/renew",
            timeout_seconds=5,
            success_keywords=["续期成功", "成功续期"],
            failure_keywords=["未获取过卡密", "无法续期", "失败"],
            cleanup_messages=True,
        )

        self.assertTrue(result.ok)
        self.assertEqual("✅ 续期成功，卡密有效期已更新", result.response_text)
        self.assertEqual(203, result.response_message_id)
        self.assertEqual([("@speed_bot", [101, 201, 202, 203])], client.deleted)


if __name__ == "__main__":
    unittest.main()
