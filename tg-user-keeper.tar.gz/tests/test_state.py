import datetime
import json
import os
import tempfile
import unittest

from tg_user_keeper.state import JsonStateStore


class JsonStateStoreTests(unittest.TestCase):
    def setUp(self) -> None:
        self.handle = tempfile.NamedTemporaryFile(delete=False)
        self.handle.close()
        self.store = JsonStateStore(self.handle.name)

    def tearDown(self) -> None:
        try:
            os.unlink(self.handle.name)
        except OSError:
            pass

    def test_mark_sign_attempt_and_get_record(self) -> None:
        now = datetime.datetime(2026, 3, 24, 9, 0, 0)
        self.store.mark_sign_attempt(
            "daily_sign",
            when=now,
            ok=True,
            response_text="签到成功",
        )
        record = self.store.get_sign_record("daily_sign")
        self.assertEqual("2026-03-24", record.get("last_success_date"))
        self.assertEqual("签到成功", record.get("last_response_text"))
        self.assertTrue(record.get("last_attempt_ok"))

    def test_mark_health_failure_then_success(self) -> None:
        fail_time = datetime.datetime(2026, 3, 24, 9, 1, 0)
        self.store.mark_health_failure(when=fail_time, response_text="timeout")
        health = self.store.get_health_state()
        self.assertEqual("fail", health.get("last_status"))
        self.assertEqual(1, int(health.get("failure_count") or 0))

        ok_time = datetime.datetime(2026, 3, 24, 9, 2, 0)
        self.store.mark_health_success(when=ok_time, response_text="ok")
        health = self.store.get_health_state()
        self.assertEqual("ok", health.get("last_status"))
        self.assertEqual(0, int(health.get("failure_count") or 0))
        self.assertEqual("ok", health.get("last_response_text"))

    def test_mark_revive_persists_reason(self) -> None:
        now = datetime.datetime(2026, 3, 24, 9, 5, 0)
        self.store.mark_revive(when=now, reason="healthcheck failed")
        health = self.store.get_health_state()
        self.assertEqual("healthcheck failed", health.get("last_revive_reason"))
        self.assertIn("2026-03-24T09:05:00", str(health.get("last_revive_at")))

    def test_task_key_health_state_is_isolated(self) -> None:
        fail_time = datetime.datetime(2026, 3, 24, 9, 1, 0)
        self.store.mark_health_failure(when=fail_time, response_text="timeout", task_key="main_bot")
        self.store.mark_health_success(
            when=datetime.datetime(2026, 3, 24, 9, 2, 0),
            response_text="ok",
            task_key="apicc_bot",
        )
        self.assertEqual("fail", self.store.get_health_state("main_bot").get("last_status"))
        self.assertEqual("ok", self.store.get_health_state("apicc_bot").get("last_status"))

    def test_legacy_healthcheck_state_migrates_to_first_task_key(self) -> None:
        with open(self.handle.name, "w", encoding="utf-8") as handle:
            json.dump(
                {
                    "sign_tasks": {},
                    "healthcheck": {
                        "last_revive_at": "2026-03-24T09:05:00",
                        "failure_count": 2,
                    },
                    "healthchecks": {},
                },
                handle,
                ensure_ascii=False,
                indent=2,
            )
        legacy = self.store.get_health_state("main_bot")
        self.assertEqual(2, int(legacy.get("failure_count") or 0))

        self.store.mark_health_failure(
            when=datetime.datetime(2026, 3, 24, 9, 6, 0),
            response_text="timeout again",
            task_key="main_bot",
        )
        migrated = self.store.get_health_state("main_bot")
        self.assertEqual(3, int(migrated.get("failure_count") or 0))
        self.assertEqual({}, self.store.get_health_state("apicc_bot"))
