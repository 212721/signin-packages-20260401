from __future__ import annotations

import asyncio
import logging
import time
from dataclasses import dataclass
from typing import Optional

try:
    from telethon import TelegramClient
    from telethon.errors import RPCError
except Exception:  # pragma: no cover
    class TelegramClient:  # type: ignore[no-redef]
        pass

    class RPCError(Exception):  # type: ignore[no-redef]
        pass


@dataclass(frozen=True)
class InteractionResult:
    ok: bool
    response_text: str
    error_text: str
    sent_message_id: Optional[int] = None
    response_message_id: Optional[int] = None


class TelegramBotInteractor:
    def __init__(self, client: TelegramClient, *, notify_peer: str = ""):
        self._client = client
        self._notify_peer = (notify_peer or "").strip()

    async def ensure_authorized(self) -> None:
        if not await self._client.is_user_authorized():
            raise RuntimeError("当前 session 未登录，请先执行 login")

    async def interactive_login(self, phone: str) -> None:
        await self._client.start(phone=phone or None)
        if not await self._client.is_user_authorized():
            raise RuntimeError("登录失败，未拿到有效 Telegram session")

    async def send_command_and_wait(
        self,
        *,
        peer: str,
        command: str,
        timeout_seconds: int,
        success_keywords: list[str],
        failure_keywords: list[str],
        cleanup_messages: bool,
    ) -> InteractionResult:
        sent_message_id: Optional[int] = None
        response_message_id: Optional[int] = None
        response_text = ""
        cleanup_message_ids: list[int] = []
        try:
            async with self._client.conversation(peer, timeout=timeout_seconds) as conversation:
                try:
                    sent = await conversation.send_message(command)
                except RPCError as exc:
                    return InteractionResult(
                        ok=False,
                        response_text="",
                        error_text=f"消息发送失败：Telegram RPC 错误：{exc}",
                        sent_message_id=sent_message_id,
                    )
                except Exception as exc:
                    logging.exception("telegram send message failed")
                    return InteractionResult(
                        ok=False,
                        response_text="",
                        error_text=f"消息发送失败：{exc}",
                        sent_message_id=sent_message_id,
                    )
                sent_message_id = getattr(sent, "id", None)
                if sent_message_id is not None:
                    cleanup_message_ids.append(sent_message_id)
                try:
                    response = await asyncio.wait_for(conversation.get_response(), timeout=timeout_seconds)
                except asyncio.TimeoutError:
                    if cleanup_messages:
                        await self._cleanup_messages(peer, cleanup_message_ids)
                    return InteractionResult(
                        ok=False,
                        response_text="",
                        error_text=f"{peer} 在 {timeout_seconds}s 内未回复",
                        sent_message_id=sent_message_id,
                    )
                response_message_id, response_text, ok, error_text = await self._resolve_response_result(
                    conversation,
                    response,
                    timeout_seconds=timeout_seconds,
                    success_keywords=success_keywords,
                    failure_keywords=failure_keywords,
                    cleanup_message_ids=cleanup_message_ids,
                )
                if cleanup_messages:
                    await self._cleanup_messages(peer, cleanup_message_ids)
                return InteractionResult(
                    ok=ok,
                    response_text=response_text,
                    error_text="" if ok else error_text,
                    sent_message_id=sent_message_id,
                    response_message_id=response_message_id,
                )
        except RPCError as exc:
            return InteractionResult(
                ok=False,
                response_text=response_text,
                error_text=f"Telegram RPC 错误：{exc}",
                sent_message_id=sent_message_id,
                response_message_id=response_message_id,
            )
        except Exception as exc:
            logging.exception("telegram interaction failed")
            return InteractionResult(
                ok=False,
                response_text=response_text,
                error_text=f"交互异常：{exc}",
                sent_message_id=sent_message_id,
                response_message_id=response_message_id,
            )

    async def notify(self, text: str) -> None:
        if not self._notify_peer:
            return
        await self._client.send_message(self._notify_peer, text)

    async def _cleanup_messages(self, peer: str, message_ids: list[int]) -> None:
        if not message_ids:
            return
        try:
            await self._client.delete_messages(peer, message_ids)
        except Exception:
            logging.exception("cleanup messages failed: peer=%s ids=%s", peer, message_ids)

    @staticmethod
    def _extract_message_text(message) -> str:
        raw = getattr(message, "raw_text", None)
        if isinstance(raw, str) and raw.strip():
            return raw.strip()
        text = getattr(message, "message", None)
        if isinstance(text, str):
            return text.strip()
        return ""

    @staticmethod
    def _evaluate_response_status(
        response_text: str,
        *,
        success_keywords: list[str],
        failure_keywords: list[str],
    ) -> tuple[bool, str]:
        text = str(response_text or "").strip()
        for keyword in failure_keywords:
            needle = str(keyword or "").strip()
            if needle and needle in text:
                return (False, f"回复命中失败关键词：{text}")
        if success_keywords:
            for keyword in success_keywords:
                needle = str(keyword or "").strip()
                if needle and needle in text:
                    return (True, "")
            return (False, f"回复未命中成功关键词：{text}")
        return (True, "")

    async def _resolve_response_result(
        self,
        conversation,
        initial_response,
        *,
        timeout_seconds: int,
        success_keywords: list[str],
        failure_keywords: list[str],
        cleanup_message_ids: list[int],
    ) -> tuple[Optional[int], str, bool, str]:
        response = initial_response
        deadline = time.monotonic() + max(1, int(timeout_seconds))
        while True:
            response_message_id = getattr(response, "id", None)
            if response_message_id is not None:
                cleanup_message_ids.append(response_message_id)
            response_text = self._extract_message_text(response)
            ok, error_text = self._evaluate_response_status(
                response_text,
                success_keywords=success_keywords,
                failure_keywords=failure_keywords,
            )
            if ok or not error_text.startswith("回复未命中成功关键词："):
                return (response_message_id, response_text, ok, error_text)

            remaining_seconds = deadline - time.monotonic()
            if remaining_seconds <= 0:
                return (response_message_id, response_text, ok, error_text)
            try:
                response = await asyncio.wait_for(conversation.get_response(), timeout=remaining_seconds)
            except asyncio.TimeoutError:
                return (response_message_id, response_text, ok, error_text)
