from __future__ import annotations

import os
import shlex
import signal
import subprocess
import time
from dataclasses import dataclass
from typing import Callable, Optional

from .config import ReviveConfig
from .state import JsonStateStore


@dataclass(frozen=True)
class ProcessInfo:
    pid: int
    args: str


@dataclass(frozen=True)
class ReviveResult:
    triggered: bool
    watchdog_started: bool
    watchdog_ready: bool
    killed_pids: list[int]
    reason: str
    diagnosis: "DiagnosisResult"
    watchdog_error: str = ""


@dataclass(frozen=True)
class DiagnosisResult:
    attempted: bool
    provider: str
    ok: bool
    command: str
    exit_code: Optional[int]
    summary: str


class ProcessMatcher:
    def __init__(self, keyword: str):
        self._keyword = (keyword or "").strip()

    def match(self, ps_output: str) -> list[ProcessInfo]:
        results: list[ProcessInfo] = []
        for line in (ps_output or "").splitlines():
            text = line.rstrip()
            if not text or self._keyword not in text:
                continue
            parts = text.split(None, 1)
            if len(parts) != 2 or not parts[0].isdigit():
                continue
            pid = int(parts[0])
            if pid == os.getpid():
                continue
            results.append(ProcessInfo(pid=pid, args=parts[1]))
        return results


class WatchdogReviver:
    def __init__(
        self,
        config: ReviveConfig,
        *,
        ps_reader: Optional[Callable[[], str]] = None,
        process_starter: Optional[Callable[[str], None]] = None,
        sleeper: Optional[Callable[[float], None]] = None,
        command_runner: Optional[Callable[[list[str], int], tuple[int, str, str]]] = None,
        killer: Optional[Callable[[int, int], None]] = None,
    ):
        self._config = config
        self._ps_reader = ps_reader or self._default_ps_reader
        self._process_starter = process_starter or self._default_process_starter
        self._sleeper = sleeper or time.sleep
        self._command_runner = command_runner or self._default_run_command
        self._killer = killer or os.kill

    def list_watchdog_processes(self) -> list[ProcessInfo]:
        return ProcessMatcher(self._config.watchdog_process_keyword).match(self._ps_reader())

    def list_bot_processes(self) -> list[ProcessInfo]:
        return ProcessMatcher(self._config.bot_process_keyword).match(self._ps_reader())

    def is_watchdog_alive(self) -> bool:
        return bool(self.list_watchdog_processes())

    def can_revive(self, last_revive_at, now, cooldown_seconds: int) -> bool:
        if last_revive_at is None:
            return True
        return (now - last_revive_at).total_seconds() >= cooldown_seconds

    def revive(self, *, peer: str, reason: str, last_revive_at, now, cooldown_seconds: int) -> ReviveResult:
        if not self.can_revive(last_revive_at, now, cooldown_seconds):
            return ReviveResult(
                triggered=False,
                watchdog_started=False,
                watchdog_ready=bool(self.is_watchdog_alive()),
                killed_pids=[],
                reason=reason,
                diagnosis=DiagnosisResult(
                    attempted=False,
                    provider="none",
                    ok=False,
                    command="",
                    exit_code=None,
                    summary="冷却时间内跳过诊断与复活",
                ),
                watchdog_error="",
            )
        diagnosis = self._run_diagnosis(peer=peer, reason=reason)
        watchdog_started = False
        watchdog_error = ""
        watchdog_ready = self.is_watchdog_alive()
        if not watchdog_ready:
            try:
                self._process_starter(self._config.watchdog_script)
            except Exception as exc:
                watchdog_error = f"watchdog 启动失败：{exc}"
            else:
                self._sleeper(2)
            watchdog_ready = self.is_watchdog_alive()
            watchdog_started = watchdog_ready
        if not watchdog_ready:
            return ReviveResult(
                triggered=True,
                watchdog_started=False,
                watchdog_ready=False,
                killed_pids=[],
                reason=reason,
                diagnosis=diagnosis,
                watchdog_error=watchdog_error,
            )
        killed_pids = self._kill_bot_processes()
        return ReviveResult(
            triggered=True,
            watchdog_started=watchdog_started,
            watchdog_ready=watchdog_ready,
            killed_pids=killed_pids,
            reason=reason,
            diagnosis=diagnosis,
            watchdog_error=watchdog_error,
        )

    @staticmethod
    def parse_last_revive_at(state_store: JsonStateStore) -> Optional[object]:
        return JsonStateStore.parse_datetime(state_store.get_health_state().get("last_revive_at"))

    def _kill_bot_processes(self) -> list[int]:
        processes = self.list_bot_processes()
        killed = [process.pid for process in processes]
        for process in processes:
            self._safe_kill(process.pid, signal.SIGTERM)
        if killed:
            self._sleeper(self._config.kill_grace_seconds)
            for process in self.list_bot_processes():
                self._safe_kill(process.pid, signal.SIGKILL)
        return killed

    def _safe_kill(self, pid: int, sig: int) -> None:
        try:
            self._killer(pid, sig)
        except ProcessLookupError:
            return
        except PermissionError:
            return

    @staticmethod
    def _default_ps_reader() -> str:
        return subprocess.check_output(
            ["ps", "-eo", "pid=,args="],
            text=True,
        )

    @staticmethod
    def _default_run_command(command: list[str], timeout_seconds: int) -> tuple[int, str, str]:
        result = subprocess.run(
            command,
            capture_output=True,
            text=True,
            timeout=timeout_seconds,
            check=False,
        )
        return (int(result.returncode), str(result.stdout or ""), str(result.stderr or ""))

    @staticmethod
    def _default_process_starter(script_path: str) -> None:
        script = (script_path or "").strip()
        if not script:
            raise ValueError("watchdog_script 不能为空")
        subprocess.Popen(
            ["/usr/bin/bash", script],
            cwd=os.path.dirname(script) or None,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            start_new_session=True,
        )

    @staticmethod
    def _sanitize_template_value(raw: str, max_length: int) -> str:
        text = str(raw or "").replace("\n", " ").replace("\r", " ").strip()
        if len(text) <= max_length:
            return text
        return text[: max(0, max_length - 3)] + "..."

    def _render_command(self, template: str, *, peer: str, reason: str) -> list[str]:
        base = str(template or "").strip()
        if not base:
            return []
        try:
            rendered = base.format(
                peer=self._sanitize_template_value(peer, 120),
                reason=self._sanitize_template_value(reason, 220),
            )
        except Exception:
            rendered = base
        return self._split_command(rendered)

    @staticmethod
    def _split_command(command: str) -> list[str]:
        text = str(command or "").strip()
        if not text:
            return []
        return shlex.split(text)

    @staticmethod
    def _summarize_output(stdout: str, stderr: str, *, exit_code: Optional[int], timed_out: bool = False) -> str:
        if timed_out:
            return "诊断命令超时"
        message = str(stdout or "").strip() or str(stderr or "").strip()
        if not message:
            return f"诊断命令退出码：{exit_code}"
        first_line = message.splitlines()[0].strip()
        if len(first_line) > 220:
            first_line = first_line[:217] + "..."
        return first_line

    def _run_diagnosis(self, *, peer: str, reason: str) -> DiagnosisResult:
        candidates = [
            ("openclaw", self._config.openclaw_diagnose_command),
            ("codex", self._config.codex_diagnose_command),
        ]
        attempted = False
        last_failure: Optional[DiagnosisResult] = None
        for provider, template in candidates:
            command_args = self._render_command(template, peer=peer, reason=reason)
            if not command_args:
                continue
            attempted = True
            try:
                exit_code, stdout, stderr = self._command_runner(command_args, self._config.diagnosis_timeout_seconds)
            except subprocess.TimeoutExpired:
                last_failure = DiagnosisResult(
                    attempted=True,
                    provider=provider,
                    ok=False,
                    command=shlex.join(command_args),
                    exit_code=None,
                    summary=self._summarize_output("", "", exit_code=None, timed_out=True),
                )
                continue
            except Exception as exc:
                last_failure = DiagnosisResult(
                    attempted=True,
                    provider=provider,
                    ok=False,
                    command=shlex.join(command_args),
                    exit_code=None,
                    summary=f"诊断命令执行异常：{exc}",
                )
                continue
            result = DiagnosisResult(
                attempted=True,
                provider=provider,
                ok=(exit_code == 0),
                command=shlex.join(command_args),
                exit_code=exit_code,
                summary=self._summarize_output(stdout, stderr, exit_code=exit_code),
            )
            if result.ok:
                return result
            last_failure = result
        if not attempted:
            return DiagnosisResult(
                attempted=False,
                provider="none",
                ok=False,
                command="",
                exit_code=None,
                summary="未配置诊断命令",
            )
        if last_failure is not None:
            return last_failure
        return DiagnosisResult(
            attempted=False,
            provider="none",
            ok=False,
            command="",
            exit_code=None,
            summary="诊断未执行",
        )
