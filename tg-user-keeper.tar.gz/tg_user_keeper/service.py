from __future__ import annotations

import asyncio
import logging
from datetime import datetime
from typing import Any, Optional

from .config import AppConfig, HealthCheckConfig, SignTaskConfig
from .revive import DiagnosisResult, ReviveResult, WatchdogReviver
from .schedule import should_run_daily_task, should_run_interval_check
from .state import JsonStateStore
from .telegram_ops import TelegramBotInteractor


class KeeperService:
    def __init__(
        self,
        config: AppConfig,
        *,
        state_store: JsonStateStore,
        interactor: TelegramBotInteractor,
        reviver: WatchdogReviver,
        mailer: Optional[Any] = None,
    ):
        self._config = config
        self._state_store = state_store
        self._interactor = interactor
        self._reviver = reviver
        self._mailer = mailer

    async def run_forever(self) -> None:
        await self._interactor.ensure_authorized()
        logging.info(
            "tg user keeper started: sign_tasks=%s healthchecks=%s",
            len(self._config.sign_tasks),
            len(self._healthcheck_tasks()),
        )
        while True:
            now = datetime.now(self._config.timezone)
            await self.run_once(now)
            await asyncio.sleep(self._config.poll_interval_seconds)

    async def run_once(self, now: datetime) -> None:
        for task in self._config.sign_tasks:
            await self._run_sign_task_if_due(task, now)
        await self._run_healthchecks(now, force=False)

    async def run_healthcheck_once(self, now: datetime) -> None:
        if not self._healthcheck_tasks():
            raise RuntimeError("未配置 healthcheck")
        await self._run_healthchecks(now, force=True)

    async def _run_sign_task_if_due(self, task: SignTaskConfig, now: datetime) -> None:
        record = self._state_store.get_sign_record(task.name)
        last_success_date = str(record.get("last_success_date") or "").strip() or None
        last_attempt_at = JsonStateStore.parse_datetime(record.get("last_attempt_at"))
        if not should_run_daily_task(
            now,
            task.run_at,
            last_success_date,
            last_attempt_at,
            task.retry_interval_minutes,
        ):
            return
        result = await self._interactor.send_command_and_wait(
            peer=task.peer,
            command=task.command,
            timeout_seconds=task.timeout_seconds,
            success_keywords=task.success_keywords,
            failure_keywords=task.failure_keywords,
            cleanup_messages=task.cleanup_messages,
        )
        response_text = result.response_text or result.error_text
        self._state_store.mark_sign_attempt(
            task.name,
            when=now,
            ok=result.ok,
            response_text=response_text,
        )
        if result.ok:
            await self._maybe_send_sign_success_email(
                task=task,
                response_text=response_text,
            )
            logging.info("sign task succeeded: %s -> %s", task.name, response_text)
            return
        logging.warning("sign task failed: %s -> %s", task.name, response_text)
        await self._interactor.notify(f"[签到失败] {task.name}\n目标：{task.peer}\n结果：{response_text}")

    def _healthcheck_tasks(self) -> list[HealthCheckConfig]:
        if self._config.healthchecks:
            return list(self._config.healthchecks)
        if self._config.healthcheck is not None:
            return [self._config.healthcheck]
        return []

    async def _run_healthcheck_if_due(self, task: HealthCheckConfig, now: datetime) -> None:
        await self._execute_healthcheck(task, now, force=False)

    async def _run_healthchecks(self, now: datetime, *, force: bool) -> None:
        tasks = self._healthcheck_tasks()
        if not tasks:
            return
        results = await asyncio.gather(
            *(self._execute_healthcheck(task, now, force=force) for task in tasks),
            return_exceptions=True,
        )
        for task, result in zip(tasks, results):
            if not isinstance(result, Exception):
                continue
            logging.exception("healthcheck task crashed: %s", self._task_label(task), exc_info=result)
            await self._interactor.notify(
                f"[探活异常] {self._task_label(task)}\n目标：{task.peer}\n结果：{result}"
            )

    async def _execute_healthcheck(self, task: HealthCheckConfig, now: datetime, *, force: bool) -> None:
        health = self._state_store.get_health_state(task.state_key)
        last_check_at = JsonStateStore.parse_datetime(health.get("last_check_at"))
        if not force and not should_run_interval_check(now, last_check_at, task.interval_minutes):
            return
        result = await self._run_healthcheck(task, now)
        if result.ok:
            self._state_store.mark_health_success(when=now, response_text=result.response_text, task_key=task.state_key)
            logging.info("healthcheck succeeded: %s -> %s", self._task_label(task), result.response_text)
            return
        failure_text = result.error_text or result.response_text
        self._state_store.mark_health_failure(when=now, response_text=failure_text, task_key=task.state_key)
        logging.warning("healthcheck failed: %s -> %s", self._task_label(task), failure_text)
        latest_health = self._state_store.get_health_state(task.state_key)
        failure_count = int(latest_health.get("failure_count") or 0)
        last_revive_at = JsonStateStore.parse_datetime(latest_health.get("last_revive_at"))
        try:
            revive = self._resolve_reviver(task).revive(
                peer=task.peer,
                reason=result.error_text or "healthcheck failed",
                last_revive_at=last_revive_at,
                now=now,
                cooldown_seconds=task.revive_cooldown_seconds,
            )
        except Exception as exc:
            logging.exception("revive flow failed: %s", self._task_label(task))
            revive = ReviveResult(
                triggered=False,
                watchdog_started=False,
                watchdog_ready=False,
                killed_pids=[],
                reason=result.error_text or "healthcheck failed",
                diagnosis=DiagnosisResult(
                    attempted=False,
                    provider="none",
                    ok=False,
                    command="",
                    exit_code=None,
                    summary=f"复活流程异常：{exc}",
                ),
                watchdog_error=f"复活流程异常：{exc}",
            )
        await self._maybe_send_email_alert(task=task, failure_text=failure_text, revive=revive, failure_count=failure_count)
        if not revive.triggered:
            await self._interactor.notify(
                f"[探活失败] {self._task_label(task)}\n目标：{task.peer}\n结果：{failure_text}\n处置：{self._build_action_summary(revive)}"
            )
            return
        self._state_store.mark_revive(when=now, reason=revive.reason, task_key=task.state_key)
        await self._interactor.notify(self._build_revive_message(task, revive, failure_text))
        if not revive.watchdog_ready:
            return
        await asyncio.sleep(task.post_revive_wait_seconds)
        retry_at = datetime.now(self._config.timezone)
        retry_result = await self._run_healthcheck(task, retry_at)
        if retry_result.ok:
            self._state_store.mark_health_success(
                when=retry_at,
                response_text=retry_result.response_text,
                task_key=task.state_key,
            )
            await self._interactor.notify(
                f"[复活成功] {self._task_label(task)}\n目标：{task.peer}\n结果：{retry_result.response_text}"
            )
            return
        self._state_store.mark_health_failure(
            when=retry_at,
            response_text=retry_result.error_text or retry_result.response_text,
            task_key=task.state_key,
        )
        await self._interactor.notify(
            f"[复活后仍失败] {self._task_label(task)}\n目标：{task.peer}\n结果：{retry_result.error_text or retry_result.response_text}"
        )

    async def _run_healthcheck(self, task: HealthCheckConfig, now: datetime):
        _ = now
        return await self._interactor.send_command_and_wait(
            peer=task.peer,
            command=task.command,
            timeout_seconds=task.timeout_seconds,
            success_keywords=task.success_keywords,
            failure_keywords=task.failure_keywords,
            cleanup_messages=task.cleanup_messages,
        )

    def _resolve_reviver(self, task: HealthCheckConfig) -> WatchdogReviver:
        revive_config = task.revive or self._config.revive
        if revive_config == self._config.revive:
            return self._reviver
        return WatchdogReviver(revive_config)

    def _task_label(self, task: HealthCheckConfig) -> str:
        return task.name or task.peer

    async def _maybe_send_email_alert(
        self,
        *,
        task: HealthCheckConfig,
        failure_text: str,
        revive: ReviveResult,
        failure_count: int,
    ) -> None:
        if self._mailer is None or not getattr(self._mailer, "enabled", False):
            return
        if failure_count > 1 and not revive.triggered:
            return
        await asyncio.to_thread(
            self._mailer.send_death_reason,
            task_name=self._task_label(task),
            peer=task.peer,
            failure_reason=failure_text,
            diagnosis_summary=revive.diagnosis.summary,
            action_summary=self._build_action_summary(revive),
        )

    async def _maybe_send_sign_success_email(
        self,
        *,
        task: SignTaskConfig,
        response_text: str,
    ) -> None:
        if self._mailer is None or not getattr(self._mailer, "enabled", False):
            return
        sender = getattr(self._mailer, "send_sign_success", None)
        if not callable(sender):
            return
        await asyncio.to_thread(
            sender,
            task_name=task.name,
            peer=task.peer,
            command=task.command,
            response_text=response_text,
        )

    def _build_action_summary(self, revive: ReviveResult) -> str:
        if revive.watchdog_error:
            return revive.watchdog_error
        if not revive.triggered:
            return "冷却时间内，跳过复活"
        if not revive.watchdog_ready:
            return "watchdog 未确认存活，未执行 bot 终止"
        if revive.killed_pids:
            return f"已终止 bot 进程：{','.join(str(pid) for pid in revive.killed_pids)}"
        return "watchdog 已确认存活，但未发现可终止 bot 进程"

    def _build_revive_message(self, task: HealthCheckConfig, revive: ReviveResult, failure_text: str) -> str:
        diagnosis = revive.diagnosis
        action_lines = [
            f"[探活失败] {self._task_label(task)}",
            f"目标：{task.peer}",
            f"失败原因：{failure_text}",
            (
                f"诊断执行：{diagnosis.provider}（{'成功' if diagnosis.ok else '失败'}）"
                if diagnosis.attempted
                else f"诊断执行：未执行（{diagnosis.summary}）"
            ),
            f"诊断摘要：{diagnosis.summary}",
            f"watchdog 异常：{revive.watchdog_error or '无'}",
            f"watchdog 新启动：{'是' if revive.watchdog_started else '否'}",
            f"watchdog 已确认存活：{'是' if revive.watchdog_ready else '否'}",
            f"已终止 bot 进程：{','.join(str(pid) for pid in revive.killed_pids) if revive.killed_pids else '无'}",
            (
                "处置：已交给 tg_watchdog 尝试复活"
                if revive.watchdog_ready
                else "处置：watchdog 未确认存活，未杀 bot，请人工检查"
            ),
        ]
        return "\n".join(action_lines)
