from __future__ import annotations

import json
import os
import re
from dataclasses import dataclass, field, replace
from datetime import time
from pathlib import Path
from typing import Any, Optional
from zoneinfo import ZoneInfo

try:
    from dotenv import load_dotenv
except Exception:  # pragma: no cover
    def load_dotenv(*_args: object, **_kwargs: object) -> bool:
        return False

from .schedule import parse_hhmm


@dataclass(frozen=True)
class SignTaskConfig:
    name: str
    peer: str
    command: str
    run_at: time
    timeout_seconds: int
    retry_interval_minutes: int
    success_keywords: list[str]
    cleanup_messages: bool
    failure_keywords: list[str] = field(default_factory=list)


@dataclass(frozen=True)
class HealthCheckConfig:
    peer: str
    command: str
    interval_minutes: int
    timeout_seconds: int
    success_keywords: list[str]
    cleanup_messages: bool
    revive_cooldown_seconds: int
    post_revive_wait_seconds: int
    failure_keywords: list[str] = field(default_factory=list)
    name: str = ""
    state_key: str = ""
    revive: Optional["ReviveConfig"] = None


@dataclass(frozen=True)
class ReviveConfig:
    watchdog_script: str
    watchdog_process_keyword: str
    bot_process_keyword: str
    kill_grace_seconds: int
    diagnosis_timeout_seconds: int
    openclaw_diagnose_command: str
    codex_diagnose_command: str


@dataclass(frozen=True)
class EmailAlertConfig:
    smtp_host: str
    smtp_port: int
    smtp_username: str
    smtp_password: str
    smtp_from: str
    to_addrs: tuple[str, ...]
    use_ssl: bool
    starttls: bool
    timeout_seconds: int
    subject_prefix: str

    @property
    def enabled(self) -> bool:
        return bool(self.smtp_host and self.smtp_from and self.to_addrs)


@dataclass(frozen=True)
class TelegramAccountConfig:
    name: str
    api_id: int
    api_hash: str
    phone: str
    session_path: str
    state_path: str
    notify_peer: str


@dataclass(frozen=True)
class AppConfig:
    api_id: int
    api_hash: str
    phone: str
    session_path: str
    timezone_name: str
    timezone: ZoneInfo
    state_path: str
    tasks_file: str
    poll_interval_seconds: int
    notify_peer: str
    sign_tasks: list[SignTaskConfig]
    healthcheck: Optional[HealthCheckConfig]
    revive: ReviveConfig
    healthchecks: tuple[HealthCheckConfig, ...] = ()
    email_alert: Optional[EmailAlertConfig] = None
    telegram_proxy: Optional[tuple[Any, ...]] = None
    accounts: tuple[TelegramAccountConfig, ...] = ()

    def primary_account(self) -> TelegramAccountConfig:
        if self.accounts:
            return self.accounts[0]
        return TelegramAccountConfig(
            name="default",
            api_id=self.api_id,
            api_hash=self.api_hash,
            phone=self.phone,
            session_path=self.session_path,
            state_path=self.state_path,
            notify_peer=self.notify_peer,
        )

    def for_account(self, account: TelegramAccountConfig) -> "AppConfig":
        return replace(
            self,
            api_id=account.api_id,
            api_hash=account.api_hash,
            phone=account.phone,
            session_path=account.session_path,
            state_path=account.state_path,
            notify_peer=account.notify_peer,
            accounts=(account,),
        )


def load_config(env_file: Optional[str] = None, *, strict_sign_tasks: bool = False) -> AppConfig:
    if env_file:
        load_dotenv(env_file, override=False)
    else:
        load_dotenv(override=False)

    tasks_file = _resolve_path(
        os.environ.get("TG_USER_KEEPER_TASKS_FILE", "./tasks.json"),
        base_dir=Path.cwd(),
    )
    timezone_name = (os.environ.get("TG_USER_KEEPER_TIMEZONE", "Asia/Shanghai").strip() or "Asia/Shanghai")
    timezone = ZoneInfo(timezone_name)
    session_path = _resolve_path(
        os.environ.get("TG_USER_SESSION_PATH", "./data/userkeeper"),
        base_dir=Path.cwd(),
    )
    state_path = _resolve_path(
        os.environ.get("TG_USER_KEEPER_STATE_PATH", "./data/state.json"),
        base_dir=Path.cwd(),
    )
    poll_interval_seconds = _env_int("TG_USER_KEEPER_POLL_INTERVAL_SECONDS", default=30, min_value=10)
    notify_peer = os.environ.get("TG_USER_KEEPER_NOTIFY_PEER", "me").strip() or "me"
    telegram_proxy = _load_telegram_proxy()
    sign_tasks = _load_sign_tasks(tasks_file, strict=strict_sign_tasks)
    revive = ReviveConfig(
        watchdog_script=_resolve_path(
            os.environ.get("TG_USER_KEEPER_WATCHDOG_SCRIPT", "/root/tg/tg-invite-bot/scripts/tg_watchdog.sh"),
            base_dir=Path.cwd(),
        ),
        watchdog_process_keyword=(
            os.environ.get("TG_USER_KEEPER_WATCHDOG_PROCESS_KEYWORD", "/root/tg/tg-invite-bot/scripts/tg_watchdog.sh").strip()
            or "/root/tg/tg-invite-bot/scripts/tg_watchdog.sh"
        ),
        bot_process_keyword=(
            os.environ.get("TG_USER_KEEPER_BOT_PROCESS_KEYWORD", "/root/tg/tg-invite-bot/bot.py").strip()
            or "/root/tg/tg-invite-bot/bot.py"
        ),
        kill_grace_seconds=_env_int("TG_USER_KEEPER_KILL_GRACE_SECONDS", default=8, min_value=1),
        diagnosis_timeout_seconds=_env_int("TG_USER_KEEPER_DIAGNOSE_TIMEOUT_SECONDS", default=30, min_value=5),
        openclaw_diagnose_command=(
            os.environ.get(
                "TG_USER_KEEPER_OPENCLAW_DIAGNOSE_COMMAND",
                'openclaw system event --text "tg-user-keeper 探活失败: {peer} 无响应，原因: {reason}" --mode now',
            ).strip()
        ),
        codex_diagnose_command=(
            os.environ.get(
                "TG_USER_KEEPER_CODEX_DIAGNOSE_COMMAND",
                (
                    'codex exec --full-auto '
                    '"在 /root/tg/tg-invite-bot 执行只读诊断：{peer} /start 无响应，原因：{reason}。'
                    '请检查 bot.py、watchdog、进程和最近日志，并输出结论。"'
                ),
            ).strip()
        ),
    )
    healthchecks = _collect_healthchecks(
        tasks_file,
        default_revive=revive,
    )
    healthcheck = healthchecks[0] if healthchecks else None
    email_alert = _load_email_alert_config()
    accounts = _load_accounts(
        base_dir=Path.cwd(),
        default_session_path=session_path,
        default_state_path=state_path,
        default_notify_peer=notify_peer,
    )
    primary_account = accounts[0]
    return AppConfig(
        api_id=primary_account.api_id,
        api_hash=primary_account.api_hash,
        phone=primary_account.phone,
        session_path=primary_account.session_path,
        timezone_name=timezone_name,
        timezone=timezone,
        state_path=primary_account.state_path,
        tasks_file=tasks_file,
        poll_interval_seconds=poll_interval_seconds,
        notify_peer=primary_account.notify_peer,
        sign_tasks=sign_tasks,
        healthcheck=healthcheck,
        revive=revive,
        healthchecks=tuple(healthchecks),
        email_alert=email_alert,
        telegram_proxy=telegram_proxy,
        accounts=tuple(accounts),
    )


def _load_sign_tasks(path: str, *, strict: bool) -> list[SignTaskConfig]:
    tasks_path = Path(path)
    if not tasks_path.exists():
        if strict:
            raise FileNotFoundError(f"任务文件不存在：{tasks_path}")
        return []
    payload = json.loads(tasks_path.read_text(encoding="utf-8"))
    items = payload.get("sign_tasks")
    if not isinstance(items, list) or not items:
        if strict:
            raise ValueError("任务文件缺少 sign_tasks 配置，且至少需要一个任务")
        return []
    tasks: list[SignTaskConfig] = []
    for index, item in enumerate(items, start=1):
        if not isinstance(item, dict):
            raise ValueError(f"sign_tasks[{index}] 必须是对象")
        name = str(item.get("name") or "").strip() or f"task_{index}"
        peer = str(item.get("peer") or "").strip()
        command = str(item.get("command") or "").strip()
        run_at_raw = str(item.get("time") or "09:00").strip() or "09:00"
        if not peer or not command:
            raise ValueError(f"sign_tasks[{index}] 缺少 peer 或 command")
        tasks.append(
            SignTaskConfig(
                name=name,
                peer=peer,
                command=command,
                run_at=parse_hhmm(run_at_raw),
                timeout_seconds=max(5, int(item.get("timeout_seconds") or 20)),
                retry_interval_minutes=max(10, int(item.get("retry_interval_minutes") or 120)),
                success_keywords=_split_keywords_from_value(item.get("success_keywords")),
                cleanup_messages=bool(item.get("cleanup_messages", True)),
                failure_keywords=_split_keywords_from_value(item.get("failure_keywords")),
            )
        )
    return tasks


def _split_keywords(raw: str) -> list[str]:
    return [part.strip() for part in (raw or "").split(",") if part.strip()]


def _split_csv(raw: str) -> list[str]:
    return [part.strip() for part in str(raw or "").split(",") if part.strip()]


def _split_keywords_from_value(raw: Any) -> list[str]:
    if isinstance(raw, list):
        return [str(part).strip() for part in raw if str(part).strip()]
    if isinstance(raw, str):
        return _split_keywords(raw)
    return []


def _split_csv_from_value(raw: Any) -> list[str]:
    if isinstance(raw, list):
        return [str(part).strip() for part in raw if str(part).strip()]
    if isinstance(raw, str):
        return _split_csv(raw)
    return []


def _load_telegram_proxy() -> Optional[tuple[Any, ...]]:
    host = os.environ.get("TG_USER_PROXY_HOST", "").strip()
    if not host:
        return None
    proxy_type = os.environ.get("TG_USER_PROXY_TYPE", "socks5").strip().lower() or "socks5"
    port = _env_int("TG_USER_PROXY_PORT", min_value=1)
    rdns = _env_bool("TG_USER_PROXY_RDNS", default=True)
    username = os.environ.get("TG_USER_PROXY_USERNAME", "").strip() or None
    password = os.environ.get("TG_USER_PROXY_PASSWORD", "").strip() or None
    return (proxy_type, host, port, rdns, username, password)


def _load_accounts(
    *,
    base_dir: Path,
    default_session_path: str,
    default_state_path: str,
    default_notify_peer: str,
) -> list[TelegramAccountConfig]:
    accounts_file = os.environ.get("TG_USER_KEEPER_ACCOUNTS_FILE", "").strip()
    if not accounts_file:
        return [
            TelegramAccountConfig(
                name=os.environ.get("TG_USER_ACCOUNT_NAME", "default").strip() or "default",
                api_id=_env_int("TG_USER_API_ID", min_value=1),
                api_hash=_require_env("TG_USER_API_HASH"),
                phone=os.environ.get("TG_USER_PHONE", "").strip(),
                session_path=default_session_path,
                state_path=default_state_path,
                notify_peer=default_notify_peer,
            )
        ]
    accounts_path = Path(_resolve_path(accounts_file, base_dir=base_dir))
    if not accounts_path.exists():
        raise FileNotFoundError(f"多账号配置文件不存在：{accounts_path}")
    payload = json.loads(accounts_path.read_text(encoding="utf-8"))
    if isinstance(payload, dict):
        raw_accounts = payload.get("accounts")
    else:
        raw_accounts = payload
    if not isinstance(raw_accounts, list) or not raw_accounts:
        raise ValueError("多账号配置文件缺少 accounts 列表")
    accounts: list[TelegramAccountConfig] = []
    for index, item in enumerate(raw_accounts, start=1):
        if not isinstance(item, dict):
            raise ValueError(f"accounts[{index}] 必须是对象")
        name = str(item.get("name") or f"account_{index}").strip() or f"account_{index}"
        suffix = _slugify_account_key(name, fallback=f"account_{index}")
        session_path = _resolve_path(
            str(item.get("session_path") or _append_path_suffix(default_session_path, suffix)),
            base_dir=accounts_path.parent,
        )
        state_path = _resolve_path(
            str(item.get("state_path") or _append_path_suffix(default_state_path, suffix)),
            base_dir=accounts_path.parent,
        )
        accounts.append(
            TelegramAccountConfig(
                name=name,
                api_id=_require_int_from_value(item.get("api_id"), field_name=f"accounts[{index}].api_id", min_value=1),
                api_hash=_require_str_from_value(item.get("api_hash"), field_name=f"accounts[{index}].api_hash"),
                phone=str(item.get("phone") or "").strip(),
                session_path=session_path,
                state_path=state_path,
                notify_peer=str(item.get("notify_peer") or default_notify_peer).strip() or default_notify_peer,
            )
        )
    return accounts


def _resolve_path(raw: str, *, base_dir: Path) -> str:
    candidate = Path((raw or "").strip() or ".")
    if candidate.is_absolute():
        return str(candidate)
    return str((base_dir / candidate).resolve())


def _append_path_suffix(raw: str, suffix: str) -> str:
    path = Path((raw or "").strip() or ".")
    if path.suffix:
        return str(path.with_name(f"{path.stem}_{suffix}{path.suffix}"))
    return str(path.with_name(f"{path.name}_{suffix}"))


def _require_env(name: str) -> str:
    value = os.environ.get(name, "").strip()
    if not value:
        raise ValueError(f"缺少环境变量 {name}")
    return value


def _env_int(name: str, default: Optional[int] = None, *, min_value: Optional[int] = None) -> int:
    raw = os.environ.get(name, "").strip()
    if not raw:
        if default is None:
            raise ValueError(f"缺少环境变量 {name}")
        value = default
    else:
        try:
            value = int(raw)
        except ValueError as exc:
            raise ValueError(f"环境变量 {name} 不是整数：{raw}") from exc
    if min_value is not None and value < min_value:
        raise ValueError(f"环境变量 {name} 不能小于 {min_value}")
    return value


def _env_bool(name: str, *, default: bool) -> bool:
    raw = os.environ.get(name, "").strip().lower()
    if not raw:
        return default
    return raw in {"1", "true", "yes", "on"}


def _bool_from_value(raw: Any, *, default: bool) -> bool:
    if raw is None or raw == "":
        return default
    if isinstance(raw, bool):
        return raw
    return str(raw).strip().lower() in {"1", "true", "yes", "on"}


def _int_from_value(raw: Any, default: int, *, min_value: int) -> int:
    try:
        value = int(raw)
    except (TypeError, ValueError):
        value = int(default)
    return max(min_value, value)


def _require_int_from_value(raw: Any, *, field_name: str, min_value: int) -> int:
    try:
        value = int(raw)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"{field_name} 必须是整数") from exc
    if value < min_value:
        raise ValueError(f"{field_name} 不能小于 {min_value}")
    return value


def _require_str_from_value(raw: Any, *, field_name: str) -> str:
    value = str(raw or "").strip()
    if not value:
        raise ValueError(f"{field_name} 不能为空")
    return value


def _slugify_healthcheck_key(raw: str, *, fallback: str) -> str:
    slug = re.sub(r"[^a-z0-9]+", "_", str(raw or "").strip().lower()).strip("_")
    return slug or fallback


def _slugify_account_key(raw: str, *, fallback: str) -> str:
    return _slugify_healthcheck_key(raw, fallback=fallback)


def _merge_revive_config(
    default_revive: ReviveConfig,
    payload: dict[str, Any],
    *,
    base_dir: Path,
) -> ReviveConfig:
    return ReviveConfig(
        watchdog_script=_resolve_path(
            str(payload.get("watchdog_script") or default_revive.watchdog_script),
            base_dir=base_dir,
        ),
        watchdog_process_keyword=(
            str(payload.get("watchdog_process_keyword") or default_revive.watchdog_process_keyword).strip()
            or default_revive.watchdog_process_keyword
        ),
        bot_process_keyword=(
            str(payload.get("bot_process_keyword") or default_revive.bot_process_keyword).strip()
            or default_revive.bot_process_keyword
        ),
        kill_grace_seconds=_int_from_value(
            payload.get("kill_grace_seconds"),
            default_revive.kill_grace_seconds,
            min_value=1,
        ),
        diagnosis_timeout_seconds=_int_from_value(
            payload.get("diagnosis_timeout_seconds"),
            default_revive.diagnosis_timeout_seconds,
            min_value=5,
        ),
        openclaw_diagnose_command=(
            str(payload.get("openclaw_diagnose_command") or default_revive.openclaw_diagnose_command).strip()
            or default_revive.openclaw_diagnose_command
        ),
        codex_diagnose_command=(
            str(payload.get("codex_diagnose_command") or default_revive.codex_diagnose_command).strip()
            or default_revive.codex_diagnose_command
        ),
    )


def _build_healthcheck_config(
    payload: dict[str, Any],
    *,
    index: int,
    default_revive: ReviveConfig,
    base_dir: Path,
) -> HealthCheckConfig:
    peer = str(payload.get("peer") or "").strip()
    if not peer:
        raise ValueError(f"healthcheck_tasks[{index}] 缺少 peer")
    name = str(payload.get("name") or peer).strip() or peer
    state_key = _slugify_healthcheck_key(
        str(payload.get("state_key") or name or peer),
        fallback=f"healthcheck_{index}",
    )
    revive = _merge_revive_config(default_revive, payload, base_dir=base_dir)
    return HealthCheckConfig(
        name=name,
        state_key=state_key,
        peer=peer,
        command=str(payload.get("command") or "/start").strip() or "/start",
        interval_minutes=_int_from_value(payload.get("interval_minutes"), 5, min_value=5),
        timeout_seconds=_int_from_value(payload.get("timeout_seconds"), 300, min_value=5),
        success_keywords=_split_keywords_from_value(payload.get("success_keywords")),
        cleanup_messages=_bool_from_value(payload.get("cleanup_messages"), default=True),
        revive_cooldown_seconds=_int_from_value(payload.get("revive_cooldown_seconds"), 300, min_value=60),
        post_revive_wait_seconds=_int_from_value(payload.get("post_revive_wait_seconds"), 20, min_value=5),
        failure_keywords=_split_keywords_from_value(payload.get("failure_keywords")),
        revive=revive,
    )


def _load_healthcheck_tasks(path: str, *, default_revive: ReviveConfig) -> list[HealthCheckConfig]:
    tasks_path = Path(path)
    if not tasks_path.exists():
        return []
    payload = json.loads(tasks_path.read_text(encoding="utf-8"))
    items = payload.get("healthcheck_tasks")
    if not isinstance(items, list) or not items:
        return []
    tasks: list[HealthCheckConfig] = []
    for index, item in enumerate(items, start=1):
        if not isinstance(item, dict):
            raise ValueError(f"healthcheck_tasks[{index}] 必须是对象")
        tasks.append(
            _build_healthcheck_config(
                item,
                index=index,
                default_revive=default_revive,
                base_dir=tasks_path.parent,
            )
        )
    return tasks


def _load_env_healthcheck(default_revive: ReviveConfig) -> Optional[HealthCheckConfig]:
    health_peer = os.environ.get("TG_USER_KEEPER_HEALTHCHECK_PEER", "").strip()
    if not health_peer:
        return None
    name = os.environ.get("TG_USER_KEEPER_HEALTHCHECK_NAME", "").strip() or health_peer
    return HealthCheckConfig(
        name=name,
        state_key=_slugify_healthcheck_key(name or health_peer, fallback="healthcheck_default"),
        peer=health_peer,
        command=os.environ.get("TG_USER_KEEPER_HEALTHCHECK_COMMAND", "/start").strip() or "/start",
        interval_minutes=_env_int("TG_USER_KEEPER_HEALTHCHECK_INTERVAL_MINUTES", default=5, min_value=5),
        timeout_seconds=_env_int("TG_USER_KEEPER_HEALTHCHECK_TIMEOUT_SECONDS", default=300, min_value=5),
        success_keywords=_split_keywords(os.environ.get("TG_USER_KEEPER_HEALTHCHECK_SUCCESS_KEYWORDS", "")),
        cleanup_messages=_env_bool("TG_USER_KEEPER_HEALTHCHECK_CLEANUP_MESSAGES", default=True),
        revive_cooldown_seconds=_env_int(
            "TG_USER_KEEPER_REVIVE_COOLDOWN_SECONDS",
            default=300,
            min_value=60,
        ),
        post_revive_wait_seconds=_env_int(
            "TG_USER_KEEPER_POST_REVIVE_WAIT_SECONDS",
            default=20,
            min_value=5,
        ),
        failure_keywords=_split_keywords(os.environ.get("TG_USER_KEEPER_HEALTHCHECK_FAILURE_KEYWORDS", "")),
        revive=default_revive,
    )


def _collect_healthchecks(tasks_file: str, *, default_revive: ReviveConfig) -> list[HealthCheckConfig]:
    merged: list[HealthCheckConfig] = []
    env_healthcheck = _load_env_healthcheck(default_revive)
    if env_healthcheck is not None:
        merged.append(env_healthcheck)
    seen: set[str] = {item.state_key for item in merged}
    for item in _load_healthcheck_tasks(tasks_file, default_revive=default_revive):
        if item.state_key in seen:
            continue
        seen.add(item.state_key)
        merged.append(item)
    return merged


def _load_email_alert_config() -> EmailAlertConfig:
    return EmailAlertConfig(
        smtp_host=os.environ.get("TG_USER_KEEPER_SMTP_HOST", "").strip(),
        smtp_port=_env_int("TG_USER_KEEPER_SMTP_PORT", default=465, min_value=1),
        smtp_username=os.environ.get("TG_USER_KEEPER_SMTP_USERNAME", "").strip(),
        smtp_password=os.environ.get("TG_USER_KEEPER_SMTP_PASSWORD", "").strip(),
        smtp_from=os.environ.get("TG_USER_KEEPER_SMTP_FROM", "").strip(),
        to_addrs=tuple(_split_csv(os.environ.get("TG_USER_KEEPER_EMAIL_TO", ""))),
        use_ssl=_env_bool("TG_USER_KEEPER_SMTP_USE_SSL", default=True),
        starttls=_env_bool("TG_USER_KEEPER_SMTP_STARTTLS", default=False),
        timeout_seconds=_env_int("TG_USER_KEEPER_SMTP_TIMEOUT_SECONDS", default=20, min_value=3),
        subject_prefix=os.environ.get("TG_USER_KEEPER_EMAIL_SUBJECT_PREFIX", "[tg-user-keeper]").strip()
        or "[tg-user-keeper]",
    )
