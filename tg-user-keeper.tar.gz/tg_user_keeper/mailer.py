from __future__ import annotations

import logging
import smtplib
import ssl
from email.message import EmailMessage

from .config import EmailAlertConfig


class SmtpAlertMailer:
    def __init__(self, config: EmailAlertConfig):
        self._config = config

    @property
    def enabled(self) -> bool:
        return self._config.enabled

    def send_death_reason(
        self,
        *,
        task_name: str,
        peer: str,
        failure_reason: str,
        diagnosis_summary: str,
        action_summary: str,
    ) -> bool:
        if not self.enabled:
            return False
        message = EmailMessage()
        subject_prefix = (self._config.subject_prefix or "").strip()
        title = task_name or peer
        subject = f"{subject_prefix} {title} 死亡原因".strip()
        message["Subject"] = subject
        message["From"] = self._config.smtp_from
        message["To"] = ", ".join(self._config.to_addrs)
        message.set_content(
            "\n".join(
                [
                    f"任务：{title}",
                    f"目标：{peer}",
                    f"死亡原因：{failure_reason}",
                    f"诊断摘要：{diagnosis_summary}",
                    f"处置结果：{action_summary}",
                ]
            )
        )
        try:
            self._send_message(message)
            return True
        except Exception:
            logging.exception("send smtp alert failed: peer=%s", peer)
            return False

    def send_sign_success(
        self,
        *,
        task_name: str,
        peer: str,
        command: str,
        response_text: str,
    ) -> bool:
        if not self.enabled:
            return False
        message = EmailMessage()
        subject_prefix = (self._config.subject_prefix or "").strip()
        title = task_name or peer
        subject = f"{subject_prefix} {title} 签到成功".strip()
        message["Subject"] = subject
        message["From"] = self._config.smtp_from
        message["To"] = ", ".join(self._config.to_addrs)
        message.set_content(
            "\n".join(
                [
                    f"任务：{title}",
                    f"目标：{peer}",
                    f"命令：{command}",
                    f"结果：{response_text or '收到回复，但内容为空'}",
                ]
            )
        )
        try:
            self._send_message(message)
            return True
        except Exception:
            logging.exception("send sign success smtp alert failed: peer=%s command=%s", peer, command)
            return False

    def _send_message(self, message: EmailMessage) -> None:
        timeout = self._config.timeout_seconds
        if self._config.use_ssl:
            context = ssl.create_default_context()
            with smtplib.SMTP_SSL(
                self._config.smtp_host,
                self._config.smtp_port,
                timeout=timeout,
                context=context,
            ) as server:
                self._login_if_needed(server)
                server.send_message(message)
            return
        with smtplib.SMTP(self._config.smtp_host, self._config.smtp_port, timeout=timeout) as server:
            if self._config.starttls:
                context = ssl.create_default_context()
                server.starttls(context=context)
            self._login_if_needed(server)
            server.send_message(message)

    def _login_if_needed(self, server: smtplib.SMTP) -> None:
        if not self._config.smtp_username:
            return
        server.login(self._config.smtp_username, self._config.smtp_password)
