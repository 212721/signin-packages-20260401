from __future__ import annotations

import json
import threading
from datetime import datetime
from pathlib import Path
from tempfile import NamedTemporaryFile
from typing import Any, Optional


class JsonStateStore:
    def __init__(self, path: str):
        self._path = Path(path)
        self._lock = threading.Lock()
        self._path.parent.mkdir(parents=True, exist_ok=True)
        if not self._path.exists():
            self._write(self._empty_state())

    @staticmethod
    def _empty_state() -> dict[str, Any]:
        return {
            "sign_tasks": {},
            "healthcheck": {},
            "healthchecks": {},
        }

    def get_sign_record(self, task_name: str) -> dict[str, Any]:
        with self._lock:
            data = self._read()
            record = data.get("sign_tasks", {}).get(task_name, {})
            return record if isinstance(record, dict) else {}

    def mark_sign_attempt(
        self,
        task_name: str,
        *,
        when: datetime,
        ok: bool,
        response_text: str,
    ) -> None:
        with self._lock:
            data = self._read()
            sign_tasks = data.setdefault("sign_tasks", {})
            record = sign_tasks.setdefault(task_name, {})
            record["last_attempt_at"] = when.isoformat()
            record["last_attempt_ok"] = ok
            record["last_response_text"] = response_text
            if ok:
                record["last_success_date"] = when.date().isoformat()
                record["last_success_at"] = when.isoformat()
            self._write(data)

    def get_health_state(self, task_key: Optional[str] = None) -> dict[str, Any]:
        with self._lock:
            data = self._read()
            if task_key:
                healthchecks = data.get("healthchecks", {})
                if not isinstance(healthchecks, dict):
                    return {}
                health = healthchecks.get(task_key, {})
                if isinstance(health, dict) and health:
                    return health
                legacy = data.get("healthcheck", {})
                if isinstance(legacy, dict) and legacy and not healthchecks:
                    return legacy
                return {}
            health = data.get("healthcheck", {})
            return health if isinstance(health, dict) else {}

    def mark_health_success(self, *, when: datetime, response_text: str, task_key: Optional[str] = None) -> None:
        with self._lock:
            data = self._read()
            health = self._get_or_create_health_record(data, task_key)
            failure_count = int(health.get("failure_count") or 0)
            health.update(
                {
                    "last_check_at": when.isoformat(),
                    "last_ok_at": when.isoformat(),
                    "last_status": "ok",
                    "last_response_text": response_text,
                    "failure_count": 0 if failure_count >= 0 else 0,
                }
            )
            self._write(data)

    def mark_health_failure(self, *, when: datetime, response_text: str, task_key: Optional[str] = None) -> None:
        with self._lock:
            data = self._read()
            health = self._get_or_create_health_record(data, task_key)
            failure_count = int(health.get("failure_count") or 0) + 1
            health.update(
                {
                    "last_check_at": when.isoformat(),
                    "last_status": "fail",
                    "last_response_text": response_text,
                    "failure_count": failure_count,
                }
            )
            self._write(data)

    def mark_revive(self, *, when: datetime, reason: str, task_key: Optional[str] = None) -> None:
        with self._lock:
            data = self._read()
            health = self._get_or_create_health_record(data, task_key)
            health["last_revive_at"] = when.isoformat()
            health["last_revive_reason"] = reason
            self._write(data)

    def _get_or_create_health_record(self, data: dict[str, Any], task_key: Optional[str]) -> dict[str, Any]:
        if task_key:
            healthchecks = data.setdefault("healthchecks", {})
            if not isinstance(healthchecks, dict):
                healthchecks = {}
                data["healthchecks"] = healthchecks
            record = healthchecks.setdefault(task_key, {})
            if not isinstance(record, dict):
                record = {}
                healthchecks[task_key] = record
            legacy = data.get("healthcheck", {})
            if not record and not healthchecks_except(healthchecks, task_key) and isinstance(legacy, dict) and legacy:
                record.update(legacy)
            return record
        health = data.setdefault("healthcheck", {})
        if not isinstance(health, dict):
            health = {}
            data["healthcheck"] = health
        return health

    @staticmethod
    def parse_datetime(raw: Any) -> Optional[datetime]:
        text = str(raw or "").strip()
        if not text:
            return None
        try:
            return datetime.fromisoformat(text)
        except ValueError:
            return None

    def _read(self) -> dict[str, Any]:
        try:
            raw = json.loads(self._path.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            raw = self._empty_state()
        sign_tasks = raw.get("sign_tasks")
        healthcheck = raw.get("healthcheck")
        healthchecks = raw.get("healthchecks")
        return {
            "sign_tasks": sign_tasks if isinstance(sign_tasks, dict) else {},
            "healthcheck": healthcheck if isinstance(healthcheck, dict) else {},
            "healthchecks": healthchecks if isinstance(healthchecks, dict) else {},
        }

    def _write(self, data: dict[str, Any]) -> None:
        self._path.parent.mkdir(parents=True, exist_ok=True)
        with NamedTemporaryFile("w", encoding="utf-8", dir=str(self._path.parent), delete=False) as handle:
            json.dump(data, handle, ensure_ascii=False, indent=2)
            temp_path = handle.name
        Path(temp_path).replace(self._path)


def healthchecks_except(items: dict[str, Any], skip_key: str) -> list[dict[str, Any]]:
    return [
        value
        for key, value in items.items()
        if key != skip_key and isinstance(value, dict) and value
    ]
