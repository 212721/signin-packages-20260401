from __future__ import annotations

from datetime import datetime, time, timedelta
from typing import Optional


def parse_hhmm(raw: str) -> time:
    text = (raw or "").strip()
    parts = text.split(":")
    if len(parts) != 2:
        raise ValueError(f"非法时间格式：{raw}")
    hour = int(parts[0])
    minute = int(parts[1])
    if hour < 0 or hour > 23 or minute < 0 or minute > 59:
        raise ValueError(f"非法时间范围：{raw}")
    return time(hour=hour, minute=minute)


def should_run_interval_check(
    now: datetime,
    last_check_at: Optional[datetime],
    interval_minutes: int,
) -> bool:
    if last_check_at is None:
        return True
    return now - last_check_at >= timedelta(minutes=interval_minutes)


def should_run_daily_task(
    now: datetime,
    task_time: time,
    last_success_date: Optional[str],
    last_attempt_at: Optional[datetime],
    retry_interval_minutes: int,
) -> bool:
    today = now.date().isoformat()
    if last_success_date == today:
        return False
    if now.time() < task_time:
        return False
    if last_attempt_at is None:
        return True
    retry_after = last_attempt_at + timedelta(minutes=retry_interval_minutes)
    return now >= retry_after
