#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import re
import smtplib
import sys
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass
from datetime import date, datetime
from email.message import EmailMessage
from http.cookiejar import CookieJar
from pathlib import Path
from typing import Any, Dict, Optional, TextIO
from zoneinfo import ZoneInfo


DEFAULT_BASE_URL = "https://www.senidc.cn"
DEFAULT_CONFIG_PATH = Path.home() / ".config" / "senidc_points_signin.json"
DEFAULT_LOG_PATH = Path(__file__).resolve().parents[1] / "data" / "senidc_points_signin.log"
SHANGHAI_TZ = ZoneInfo("Asia/Shanghai")


class SenidcSigninError(Exception):
    pass


def parse_response_code(payload: Dict[str, Any], field: str = "code") -> int:
    raw = payload.get(field)
    try:
        return int(raw)
    except (TypeError, ValueError) as exc:
        raise SenidcSigninError(f"invalid response {field}: {raw!r}") from exc


@dataclass
class SMTPConfig:
    host: str
    port: int
    username: str
    password: str
    to_email: str
    from_email: str
    timeout: int = 20
    use_starttls: bool = True


@dataclass
class SigninConfig:
    email: str
    password: str
    base_url: str = DEFAULT_BASE_URL
    timeout: int = 20
    smtp: Optional[SMTPConfig] = None


class SenidcSigninClient:
    def __init__(self, config: SigninConfig) -> None:
        self.base_url = config.base_url.strip().rstrip("/")
        self.email = config.email.strip()
        self.password = config.password
        self.timeout = max(5, int(config.timeout))
        self.cookie_jar = CookieJar()
        self.opener = urllib.request.build_opener(
            urllib.request.HTTPCookieProcessor(self.cookie_jar)
        )

    def _make_request(
        self,
        path: str,
        *,
        method: str = "GET",
        data: Optional[bytes] = None,
        headers: Optional[Dict[str, str]] = None,
    ) -> urllib.response.addinfourl:
        safe_path = path if path.startswith("/") else f"/{path}"
        url = f"{self.base_url}{safe_path}"
        req = urllib.request.Request(
            url=url,
            data=data,
            headers=headers or {},
            method=method.upper(),
        )
        return self.opener.open(req, timeout=self.timeout)

    def _request_text(
        self,
        path: str,
        *,
        method: str = "GET",
        data: Optional[bytes] = None,
        headers: Optional[Dict[str, str]] = None,
    ) -> tuple[str, str]:
        try:
            with self._make_request(path, method=method, data=data, headers=headers) as resp:
                body = resp.read().decode("utf-8", errors="replace")
                final_url = resp.geturl()
        except urllib.error.HTTPError as exc:
            body = exc.read().decode("utf-8", errors="replace")
            raise SenidcSigninError(f"HTTP {exc.code}: {body[:200]}") from exc
        except urllib.error.URLError as exc:
            raise SenidcSigninError(f"request failed: {exc}") from exc
        return body, final_url

    def _request_json(
        self,
        path: str,
        *,
        method: str = "GET",
        data: Optional[bytes] = None,
        headers: Optional[Dict[str, str]] = None,
    ) -> Dict[str, Any]:
        body, _ = self._request_text(path, method=method, data=data, headers=headers)
        try:
            parsed = json.loads(body)
        except json.JSONDecodeError as exc:
            raise SenidcSigninError(f"non-json response: {body[:200]}") from exc
        if not isinstance(parsed, dict):
            raise SenidcSigninError("unexpected json payload")
        return parsed

    def login(self) -> None:
        common_headers = {
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            "User-Agent": (
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                "AppleWebKit/537.36 (KHTML, like Gecko) "
                "Chrome/124.0.0.0 Safari/537.36"
            ),
        }
        login_page, _ = self._request_text("/login", headers=common_headers)
        match = re.search(r'name="token"\s+value="([^"]+)"', login_page)
        if not match:
            raise SenidcSigninError("login token not found")

        payload = urllib.parse.urlencode(
            {
                "token": match.group(1),
                "email": self.email,
                "password": self.password,
            }
        ).encode("utf-8")
        body, final_url = self._request_text(
            "/login?action=email",
            method="POST",
            data=payload,
            headers={
                **common_headers,
                "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
                "Referer": f"{self.base_url}/login",
            },
        )
        if "/clientarea" not in final_url and "退出" not in body and "用户中心" not in body:
            raise SenidcSigninError("login did not reach client area")

    def fetch_month_status(self, target_date: date) -> Dict[str, Any]:
        ym = target_date.strftime("%Y%m")
        query = urllib.parse.urlencode(
            {
                "_plugin": "points_mall",
                "_controller": "index",
                "_action": "signindata",
                "date": ym,
            }
        )
        payload = self._request_json(
            f"/addons?{query}",
            headers={
                "Accept": "application/json, text/plain, */*",
                "Referer": f"{self.base_url}/addons?_plugin=points_mall&_controller=index&_action=signin",
                "User-Agent": (
                    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                    "AppleWebKit/537.36 (KHTML, like Gecko) "
                    "Chrome/124.0.0.0 Safari/537.36"
                ),
                "X-Requested-With": "XMLHttpRequest",
            },
        )
        if parse_response_code(payload) != 200:
            raise SenidcSigninError(str(payload.get("msg") or "signindata failed"))
        return payload

    def sign(self, target_date: date) -> Dict[str, Any]:
        body = json.dumps({"date": target_date.isoformat()}, ensure_ascii=True).encode("utf-8")
        payload = self._request_json(
            "/addons?_plugin=points_mall&_controller=index&_action=sign",
            method="POST",
            data=body,
            headers={
                "Accept": "application/json, text/plain, */*",
                "Content-Type": "application/json",
                "Referer": f"{self.base_url}/addons?_plugin=points_mall&_controller=index&_action=signin",
                "User-Agent": (
                    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                    "AppleWebKit/537.36 (KHTML, like Gecko) "
                    "Chrome/124.0.0.0 Safari/537.36"
                ),
                "X-Requested-With": "XMLHttpRequest",
            },
        )
        return payload


def _parse_bool(raw: Any, *, field: str) -> bool:
    if isinstance(raw, bool):
        return raw
    if isinstance(raw, str):
        value = raw.strip().lower()
        if value in {"1", "true", "yes", "on"}:
            return True
        if value in {"0", "false", "no", "off"}:
            return False
    raise SenidcSigninError(f"invalid {field}: {raw!r}")


def load_smtp_config(raw: Any) -> Optional[SMTPConfig]:
    if raw is None:
        return None
    if not isinstance(raw, dict):
        raise SenidcSigninError("smtp config must be a json object")

    host = str(raw.get("host") or "").strip()
    username = str(raw.get("username") or "").strip()
    password = str(raw.get("password") or "")
    to_email = str(raw.get("to_email") or "").strip()
    from_email = str(raw.get("from_email") or username).strip()
    if not host or not username or not password or not to_email:
        raise SenidcSigninError("smtp config requires host, username, password and to_email")

    raw_port = raw.get("port", 587)
    try:
        port = int(raw_port)
    except (TypeError, ValueError) as exc:
        raise SenidcSigninError(f"invalid smtp port value: {raw_port!r}") from exc

    raw_timeout = raw.get("timeout", 20)
    try:
        timeout = int(raw_timeout)
    except (TypeError, ValueError) as exc:
        raise SenidcSigninError(f"invalid smtp timeout value: {raw_timeout!r}") from exc

    raw_use_starttls = raw.get("use_starttls", True)
    use_starttls = _parse_bool(raw_use_starttls, field="smtp use_starttls value")

    return SMTPConfig(
        host=host,
        port=max(1, port),
        username=username,
        password=password,
        to_email=to_email,
        from_email=from_email,
        timeout=max(5, timeout),
        use_starttls=use_starttls,
    )


def load_config(path: Path) -> SigninConfig:
    try:
        raw = path.read_text(encoding="utf-8")
    except FileNotFoundError as exc:
        raise SenidcSigninError(f"config not found: {path}") from exc

    try:
        payload = json.loads(raw)
    except json.JSONDecodeError as exc:
        raise SenidcSigninError(f"invalid config json: {path}") from exc

    if not isinstance(payload, dict):
        raise SenidcSigninError("config must be a json object")

    email = str(payload.get("email") or "").strip()
    password = str(payload.get("password") or "")
    if not email or not password:
        raise SenidcSigninError("config requires email and password")

    raw_timeout = payload.get("timeout", 20)
    try:
        timeout = int(raw_timeout)
    except (TypeError, ValueError) as exc:
        raise SenidcSigninError(f"invalid timeout value: {raw_timeout!r}") from exc

    smtp = load_smtp_config(payload.get("smtp"))

    return SigninConfig(
        email=email,
        password=password,
        base_url=str(payload.get("base_url") or DEFAULT_BASE_URL).strip() or DEFAULT_BASE_URL,
        timeout=timeout,
        smtp=smtp,
    )


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Daily sign-in for senidc points mall.")
    parser.add_argument(
        "--config",
        default=str(DEFAULT_CONFIG_PATH),
        help=f"config path, default: {DEFAULT_CONFIG_PATH}",
    )
    parser.add_argument(
        "--date",
        default="",
        help="target sign date in YYYY-MM-DD, default: today in Asia/Shanghai",
    )
    parser.add_argument(
        "--check-only",
        action="store_true",
        help="only check whether the target date is already signed",
    )
    parser.add_argument(
        "--log-file",
        default=str(DEFAULT_LOG_PATH),
        help=f"log file path, default: {DEFAULT_LOG_PATH}",
    )
    return parser.parse_args()


def resolve_target_date(raw_value: str) -> date:
    if raw_value:
        try:
            return date.fromisoformat(raw_value)
        except ValueError as exc:
            raise SenidcSigninError(f"invalid --date value: {raw_value}") from exc
    return datetime.now(SHANGHAI_TZ).date()


def append_log(log_path: Path, message: str) -> None:
    log_path.parent.mkdir(parents=True, exist_ok=True)
    timestamp = datetime.now(SHANGHAI_TZ).isoformat(timespec="seconds")
    with log_path.open("a", encoding="utf-8") as fh:
        fh.write(f"{timestamp} {message}\n")


def emit_message(log_path: Path, message: str, *, stream: TextIO) -> None:
    try:
        interactive = bool(stream.isatty())
    except Exception:
        interactive = False
    if interactive:
        print(message, file=stream)
    append_log(log_path, message)


def send_success_email(config: Optional[SMTPConfig], target_date: date, message: str) -> Optional[str]:
    if config is None:
        return None

    email_message = EmailMessage()
    email_message["From"] = config.from_email
    email_message["To"] = config.to_email
    email_message["Subject"] = f"[senidc] sign-in success {target_date.isoformat()}"
    email_message.set_content(
        "\n".join(
            [
                "Senidc sign-in completed successfully.",
                f"Date: {target_date.isoformat()}",
                f"Message: {message}",
                f"Sent at: {datetime.now(SHANGHAI_TZ).isoformat(timespec='seconds')}",
            ]
        )
    )

    try:
        with smtplib.SMTP(config.host, config.port, timeout=config.timeout) as client:
            client.ehlo()
            if config.use_starttls:
                client.starttls()
                client.ehlo()
            client.login(config.username, config.password)
            client.send_message(email_message)
    except (OSError, smtplib.SMTPException) as exc:
        raise SenidcSigninError(f"email notification failed: {exc}") from exc

    return config.to_email


def main() -> int:
    args = parse_args()
    config_path = Path(args.config).expanduser()
    log_path = Path(args.log_file).expanduser()

    try:
        config = load_config(config_path)
        target_date = resolve_target_date(args.date)
        client = SenidcSigninClient(config)
        client.login()

        status_payload = client.fetch_month_status(target_date)
        status_data = status_payload.get("data")
        if not isinstance(status_data, dict):
            raise SenidcSigninError("signindata payload missing data object")

        signed_dates = status_data.get("signedDates")
        # 兼容旧格式（字典）和新格式（数组）
        is_signed = False
        if isinstance(signed_dates, dict):
            is_signed = bool(signed_dates.get(target_date.isoformat()))
        elif isinstance(signed_dates, list):
            is_signed = target_date.isoformat() in signed_dates
        else:
            raise SenidcSigninError("signindata payload missing signedDates")

        if is_signed:
            message = f"already signed for {target_date.isoformat()}"
            emit_message(log_path, message, stream=sys.stdout)
            return 0

        if args.check_only:
            message = f"not signed for {target_date.isoformat()}"
            emit_message(log_path, message, stream=sys.stdout)
            return 0

        sign_payload = client.sign(target_date)
        code = parse_response_code(sign_payload)
        msg = str(sign_payload.get("msg") or "").strip()
        if code not in {200, 400}:
            raise SenidcSigninError(msg or f"unexpected sign response code={code}")
        if code == 400 and "已经签到" not in msg:
            raise SenidcSigninError(msg or "sign request rejected")

        verify_payload = client.fetch_month_status(target_date)
        verify_data = verify_payload.get("data")
        verify_signed_dates = verify_data.get("signedDates") if isinstance(verify_data, dict) else None
        # 兼容旧格式（字典）和新格式（数组）
        verify_is_signed = False
        if isinstance(verify_signed_dates, dict):
            verify_is_signed = bool(verify_signed_dates.get(target_date.isoformat()))
        elif isinstance(verify_signed_dates, list):
            verify_is_signed = target_date.isoformat() in verify_signed_dates

        if not verify_is_signed:
            raise SenidcSigninError("verification failed after sign request")

        message = msg or f"signed for {target_date.isoformat()}"
        emit_message(log_path, message, stream=sys.stdout)
        try:
            sent_to = send_success_email(config.smtp, target_date, message)
        except SenidcSigninError as exc:
            emit_message(log_path, f"warning: {exc}", stream=sys.stderr)
        else:
            if sent_to:
                emit_message(log_path, f"notification email sent to {sent_to}", stream=sys.stdout)
        return 0
    except SenidcSigninError as exc:
        message = f"error: {exc}"
        emit_message(log_path, message, stream=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
