# senidc-points-signin

用于森云积分商城的每日自动签到脚本。

脚本文件：

- `senidc_points_signin.py`

## 功能说明

- 登录森云站点
- 查询指定日期是否已签到
- 未签到时自动执行签到
- 签到后再次校验结果
- 记录执行日志
- 可选发送 SMTP 成功通知

## 运行环境

- Python 3.10+
- Linux

脚本仅使用 Python 标准库，无需额外安装依赖。

## 配置文件

默认配置文件路径：

```text
~/.config/senidc_points_signin.json
```

示例：

```json
{
  "email": "your-account@example.com",
  "password": "your-password",
  "base_url": "https://www.senidc.cn",
  "timeout": 20,
  "smtp": {
    "host": "smtp.mailersend.net",
    "port": 2525,
    "username": "your-smtp-username",
    "password": "your-smtp-password",
    "to_email": "your-receive@example.com",
    "from_email": "your-sender@example.com",
    "timeout": 20,
    "use_starttls": true
  }
}
```

字段说明：

- `email`：森云账号
- `password`：森云密码
- `base_url`：站点地址，默认 `https://www.senidc.cn`
- `timeout`：请求超时秒数，默认 `20`
- `smtp`：可选，配置后在签到成功时发送邮件通知

`smtp` 字段说明：

- `host`：SMTP 服务器地址
- `port`：SMTP 端口
- `username`：SMTP 用户名
- `password`：SMTP 密码或授权码
- `to_email`：收件人邮箱
- `from_email`：发件人邮箱；不填时默认使用 `username`
- `timeout`：SMTP 超时秒数，默认 `20`
- `use_starttls`：是否启用 `STARTTLS`，默认 `true`

## 手动执行

```bash
python3 "./senidc_points_signin.py"
```

仅检查今天是否已签到：

```bash
python3 "./senidc_points_signin.py" --check-only
```

指定日期：

```bash
python3 "./senidc_points_signin.py" --date "2026-03-27"
```

指定日志文件：

```bash
python3 "./senidc_points_signin.py" --log-file "/root/senidc-points-signin/data/signin.log"
```

如果配置了 `smtp`，脚本会在“实际签到成功并完成校验”后发送一封邮件。

## 持续运行方案

这个任务本质上不需要常驻进程。更合理的做法是“定时执行”，而不是让 Python 脚本一直挂着。

推荐优先级：

1. `systemd timer`
2. `cron`

### 方案一：systemd timer

创建服务文件 `/etc/systemd/system/senidc-signin.service`：

```ini
[Unit]
Description=Senidc daily sign-in
Wants=network-online.target
After=network-online.target

[Service]
Type=oneshot
User=root
WorkingDirectory=/root/senidc-points-signin
ExecStart=/usr/bin/python3 /root/senidc-points-signin/senidc_points_signin.py --log-file /root/senidc-points-signin/data/signin.log
```

创建定时器 `/etc/systemd/system/senidc-signin.timer`：

```ini
[Unit]
Description=Run Senidc daily sign-in every day

[Timer]
OnCalendar=*-*-* 09:05:00
Persistent=true
Unit=senidc-signin.service

[Install]
WantedBy=timers.target
```

启用：

```bash
sudo systemctl daemon-reload
sudo systemctl enable --now senidc-signin.timer
sudo systemctl list-timers --all | grep "senidc-signin"
```

查看运行日志：

```bash
sudo journalctl -u "senidc-signin.service" -n 50 --no-pager
tail -n 50 "/root/senidc-points-signin/data/signin.log"
```

### 方案二：cron

编辑计划任务：

```bash
crontab -e
```

每天上午 `09:05` 执行：

```cron
5 9 * * * /usr/bin/python3 /root/senidc-points-signin/senidc_points_signin.py --log-file /root/senidc-points-signin/data/signin.log
```

## 命令行参数

```text
--config    配置文件路径
--date      指定签到日期，格式 YYYY-MM-DD
--check-only 只检查，不执行签到
--log-file  日志文件路径
```

## 常见问题

### 1. 已经签到会怎样

脚本会正常退出，并写入类似下面的日志：

```text
already signed for 2026-03-27
```

### 2. 登录失败怎么办

优先检查：

- 账号密码是否正确
- 站点登录页面结构是否变化
- 当前机器网络是否可访问 `https://www.senidc.cn`

### 3. 可以一直在本地持续运行吗

可以，但不建议写成常驻死循环。这个需求是典型的每日任务，直接用 `systemd timer` 或 `cron` 更稳定，也更省资源。

### 4. SMTP 发不出去怎么办

优先检查：

- `to_email` 是否填写正确
- `from_email` 是否符合你的 SMTP 服务商要求
- 服务商是否要求 `STARTTLS`
- 端口是否允许出站访问

## 后续扩展

后续还可以继续加：

- 失败重试
- 多账号签到
- Docker 部署
