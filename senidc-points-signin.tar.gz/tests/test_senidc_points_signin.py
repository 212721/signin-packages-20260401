import json
import tempfile
import unittest
from argparse import Namespace
from datetime import date
from pathlib import Path
from unittest.mock import patch

import senidc_points_signin as signin


class FakeSMTP:
    instances = []

    def __init__(self, host: str, port: int, timeout: int) -> None:
        self.host = host
        self.port = port
        self.timeout = timeout
        self.calls = []
        self.logged_in = None
        self.message = None
        FakeSMTP.instances.append(self)

    def __enter__(self) -> "FakeSMTP":
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        return None

    def ehlo(self) -> None:
        self.calls.append("ehlo")

    def starttls(self) -> None:
        self.calls.append("starttls")

    def login(self, username: str, password: str) -> None:
        self.logged_in = (username, password)

    def send_message(self, message) -> None:
        self.message = message


class SenidcPointsSigninTests(unittest.TestCase):
    def test_load_config_supports_smtp_settings(self) -> None:
        with tempfile.TemporaryDirectory() as tmp_dir:
            config_path = Path(tmp_dir) / "config.json"
            config_path.write_text(
                json.dumps(
                    {
                        "email": "account@example.com",
                        "password": "secret",
                        "smtp": {
                            "host": "smtp.mailersend.net",
                            "port": 2525,
                            "username": "mailer@example.com",
                            "password": "smtp-secret",
                            "to_email": "notify@example.com",
                        },
                    }
                ),
                encoding="utf-8",
            )

            config = signin.load_config(config_path)

            self.assertIsNotNone(config.smtp)
            assert config.smtp is not None
            self.assertEqual("smtp.mailersend.net", config.smtp.host)
            self.assertEqual(2525, config.smtp.port)
            self.assertEqual("mailer@example.com", config.smtp.from_email)
            self.assertTrue(config.smtp.use_starttls)

    def test_send_success_email_uses_starttls_and_delivers_message(self) -> None:
        smtp_config = signin.SMTPConfig(
            host="smtp.mailersend.net",
            port=2525,
            username="mailer@example.com",
            password="smtp-secret",
            to_email="notify@example.com",
            from_email="sender@example.com",
        )

        FakeSMTP.instances.clear()
        with patch.object(signin.smtplib, "SMTP", FakeSMTP):
            sent_to = signin.send_success_email(
                smtp_config,
                date(2026, 3, 27),
                "signed for 2026-03-27",
            )

        self.assertEqual("notify@example.com", sent_to)
        self.assertEqual(1, len(FakeSMTP.instances))
        client = FakeSMTP.instances[0]
        self.assertEqual("smtp.mailersend.net", client.host)
        self.assertEqual(2525, client.port)
        self.assertEqual(["ehlo", "starttls", "ehlo"], client.calls)
        self.assertEqual(("mailer@example.com", "smtp-secret"), client.logged_in)
        self.assertIsNotNone(client.message)
        self.assertEqual("sender@example.com", client.message["From"])
        self.assertEqual("notify@example.com", client.message["To"])

    def test_main_sends_email_after_successful_sign(self) -> None:
        class FakeClient:
            def __init__(self, _config: signin.SigninConfig) -> None:
                self.fetch_calls = 0

            def login(self) -> None:
                return None

            def fetch_month_status(self, _target_date: signin.date):
                self.fetch_calls += 1
                if self.fetch_calls == 1:
                    return {"code": 200, "data": {"signedDates": {}}}
                return {"code": 200, "data": {"signedDates": {"2026-03-27": True}}}

            def sign(self, _target_date: signin.date):
                return {"code": 200, "msg": "签到成功"}

        with tempfile.TemporaryDirectory() as tmp_dir:
            config_path = Path(tmp_dir) / "config.json"
            log_path = Path(tmp_dir) / "signin.log"
            config_path.write_text(
                json.dumps(
                    {
                        "email": "account@example.com",
                        "password": "secret",
                        "smtp": {
                            "host": "smtp.mailersend.net",
                            "port": 2525,
                            "username": "mailer@example.com",
                            "password": "smtp-secret",
                            "to_email": "notify@example.com",
                        },
                    }
                ),
                encoding="utf-8",
            )
            args = Namespace(
                config=str(config_path),
                date="2026-03-27",
                check_only=False,
                log_file=str(log_path),
            )
            with patch.object(signin, "parse_args", return_value=args), patch.object(
                signin, "SenidcSigninClient", FakeClient
            ), patch.object(signin, "send_success_email", return_value="notify@example.com") as send_email:
                self.assertEqual(0, signin.main())

            send_email.assert_called_once()
            log_text = log_path.read_text(encoding="utf-8")
            self.assertIn("签到成功", log_text)
            self.assertIn("notification email sent to notify@example.com", log_text)

    def test_main_keeps_success_when_email_notification_fails(self) -> None:
        class FakeClient:
            def __init__(self, _config: signin.SigninConfig) -> None:
                self.fetch_calls = 0

            def login(self) -> None:
                return None

            def fetch_month_status(self, _target_date: signin.date):
                self.fetch_calls += 1
                if self.fetch_calls == 1:
                    return {"code": 200, "data": {"signedDates": {}}}
                return {"code": 200, "data": {"signedDates": {"2026-03-27": True}}}

            def sign(self, _target_date: signin.date):
                return {"code": 200, "msg": "签到成功"}

        with tempfile.TemporaryDirectory() as tmp_dir:
            config_path = Path(tmp_dir) / "config.json"
            log_path = Path(tmp_dir) / "signin.log"
            config_path.write_text(
                json.dumps(
                    {
                        "email": "account@example.com",
                        "password": "secret",
                        "smtp": {
                            "host": "smtp.mailersend.net",
                            "port": 2525,
                            "username": "mailer@example.com",
                            "password": "smtp-secret",
                            "to_email": "notify@example.com",
                        },
                    }
                ),
                encoding="utf-8",
            )
            args = Namespace(
                config=str(config_path),
                date="2026-03-27",
                check_only=False,
                log_file=str(log_path),
            )
            with patch.object(signin, "parse_args", return_value=args), patch.object(
                signin, "SenidcSigninClient", FakeClient
            ), patch.object(
                signin,
                "send_success_email",
                side_effect=signin.SenidcSigninError("email notification failed: auth error"),
            ):
                self.assertEqual(0, signin.main())

            log_text = log_path.read_text(encoding="utf-8")
            self.assertIn("签到成功", log_text)
            self.assertIn("warning: email notification failed: auth error", log_text)


if __name__ == "__main__":
    unittest.main()
