# DOME CDN 自动续费脚本

这是一个独立的 Python 脚本，直接按照 DOME CDN 当前前端的真实接口实现：

- 登录：`POST /login`
- 我的套餐：`GET /user-packages`
- 续费报价：`GET /user-packages/{id}?duration=month|quarter|year`
- 执行续费：`PUT /user-packages/{id}`，请求体 `{"duration":"month|quarter|year"}`

## 当前已验证的事实

在 **2026-03-28** 我用你提供并确认后的账号完成了只读验证：

- 账号可以正常登录
- 套餐管理页面的“续费”按钮确实走 `PUT /user-packages/{id}`
- 你当前账号有 1 个套餐，`user_package_id=359`
- 当前到期时间是 `2026-04-04 01:31:57`
- 套餐配置的续费窗口是 `3` 天
- 当前距离到期还有 `6` 天，所以脚本 dry-run 会判定“未到续费窗口”
- 该套餐 `month` 续费报价为 `0.0` 元，`quarter` 为 `1.0` 元，`year` 为 `3.0` 元

## 文件

- `domecdn_auto_renew.py`：主脚本
- `.env.example`：环境变量示例

## 配置

```bash
cd "/root/domecdn-renew"
cp ".env.example" ".env"
```

支持两种认证方式，二选一：

1. `DOMECDN_ACCESS_TOKEN`
2. `DOMECDN_ACCOUNT` + `DOMECDN_PASSWORD`

自动续费相关配置：

- `DOMECDN_RENEW_DURATION=month|quarter|year`
- `DOMECDN_RENEW_THRESHOLD_DAYS=3`
- `DOMECDN_FREE_ONLY=1`

说明：

- 如果套餐接口里带了 `before_exp_days_renew`，脚本会优先使用套餐自己的续费窗口。
- 如果套餐没有这个配置，脚本才回退到 `DOMECDN_RENEW_THRESHOLD_DAYS`。
- 如果 `DOMECDN_FREE_ONLY=1`，脚本只会自动执行 `total_price == 0` 的续费。

## 用法

### 1. 巡检

```bash
cd "/root/domecdn-renew"
python3 "domecdn_auto_renew.py" inspect
```

JSON 输出：

```bash
cd "/root/domecdn-renew"
python3 "domecdn_auto_renew.py" --json inspect
```

### 2. 生成续费计划

默认只做 dry-run，不会真的续费：

```bash
cd "/root/domecdn-renew"
python3 "domecdn_auto_renew.py" renew
```

指定时长：

```bash
cd "/root/domecdn-renew"
python3 "domecdn_auto_renew.py" renew --duration month
```

手动指定某个 `user_package_id`：

```bash
cd "/root/domecdn-renew"
python3 "domecdn_auto_renew.py" renew --resource-id 359
```

说明：

- 不传 `--resource-id` 时，脚本会遍历当前账号全部用户套餐。
- 传了 `--resource-id` 时，会强制针对指定套餐生成续费计划，即使还没进入自动续费窗口。

### 3. 真实执行续费

```bash
cd "/root/domecdn-renew"
python3 "domecdn_auto_renew.py" renew --execute --confirm LIVE_RENEWAL
```

为了避免误操作，真实执行必须同时带：

- `--execute`
- `--confirm LIVE_RENEWAL`

## 自动化调度

如果你要每天自动检查一次，可以自己加 cron：

```bash
0 3 * * * cd "/root/domecdn-renew" && /usr/bin/python3 "/root/domecdn-renew/domecdn_auto_renew.py" renew >> "/root/domecdn-renew/renew.log" 2>&1
```

这条命令默认仍然只是 dry-run。

如果你确认要自动真实续费，再改成：

```bash
0 3 * * * cd "/root/domecdn-renew" && /usr/bin/python3 "/root/domecdn-renew/domecdn_auto_renew.py" renew --execute --confirm LIVE_RENEWAL >> "/root/domecdn-renew/renew.log" 2>&1
```

## 当前实测结果

当前账号在我验证时的 dry-run 结果是：

- 余额：`0.0`
- 套餐数量：`1`
- 当前套餐：`大陆速防-X级`
- 到期时间：`2026-04-04 01:31:57`
- 距到期：`6` 天
- 自动续费窗口：`3` 天
- `month` 续费价格：`0.0`
- 当前结论：还不会自动续费

也就是说，按当前逻辑，等它进入到期前 3 天窗口后，脚本才会把它视为可自动续费目标。
