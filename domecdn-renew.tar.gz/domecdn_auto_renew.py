#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import os
import sys
from dataclasses import dataclass
from datetime import datetime
from http.cookiejar import CookieJar
from pathlib import Path
from typing import Any
from urllib.error import HTTPError, URLError
from urllib.parse import urlencode, urljoin
from urllib.request import HTTPCookieProcessor, Request, build_opener


DEFAULT_BASE_URL = "https://console.domecdn.com"
DEFAULT_TIMEOUT = 20.0
ENV_FILE_NAME = ".env"
SCRIPT_DIR = Path(__file__).resolve().parent


class ConfigError(RuntimeError):
    pass


class ApiError(RuntimeError):
    def __init__(
        self,
        message: str,
        *,
        code: Any = None,
        status: int | None = None,
        body: str | None = None,
    ) -> None:
        super().__init__(message)
        self.code = code
        self.status = status
        self.body = body


def load_env_file(path: Path) -> None:
    if not path.is_file():
        return

    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue

        key, value = line.split("=", 1)
        key = key.strip()
        value = value.strip()

        if not key or key in os.environ:
            continue

        if len(value) >= 2 and value[0] == value[-1] and value[0] in {"'", '"'}:
            value = value[1:-1]

        os.environ[key] = value


def normalize_list(data: Any) -> list[dict[str, Any]]:
    if isinstance(data, list):
        return [item for item in data if isinstance(item, dict)]

    if isinstance(data, dict):
        for key in ("items", "rows", "list", "data"):
            value = data.get(key)
            if isinstance(value, list):
                return [item for item in value if isinstance(item, dict)]

    return []


def safe_int(value: Any) -> int | None:
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


def site_is_expired(site: dict[str, Any], wanted_state: str) -> bool:
    state = str(site.get("site_state", "")).strip()
    return state == wanted_state


def format_amount_cents(amount: Any) -> str:
    cents = safe_int(amount)
    if cents is None:
        return str(amount)
    return f"{cents / 100:.2f}"


def json_dump(data: Any) -> str:
    return json.dumps(data, ensure_ascii=False, indent=2, sort_keys=True)


def parse_datetime(value: Any) -> datetime | None:
    if not value or not isinstance(value, str):
        return None

    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d"):
        try:
            return datetime.strptime(value, fmt)
        except ValueError:
            continue

    return None


def calc_days_left(end_at: Any, now: datetime | None = None) -> int | None:
    dt = parse_datetime(end_at)
    if dt is None:
        return None

    now = now or datetime.now()
    return (dt - now).days


def safe_float(value: Any) -> float | None:
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def resolve_threshold_days(package_info: dict[str, Any] | None, fallback_days: int) -> int:
    if not isinstance(package_info, dict):
        return fallback_days

    raw = safe_int(package_info.get("before_exp_days_renew"))
    if raw is None or raw < 0:
        return fallback_days

    return raw


@dataclass
class Settings:
    base_url: str
    timeout: float
    account: str | None
    password: str | None
    access_token: str | None
    renew_duration: str
    renew_threshold_days: int
    free_only: bool


class DomeCdnClient:
    def __init__(self, base_url: str, *, timeout: float, access_token: str | None = None) -> None:
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.access_token = access_token
        self._opener = build_opener(HTTPCookieProcessor(CookieJar()))

    def request(
        self,
        method: str,
        path: str,
        *,
        payload: Any | None = None,
        include_token: bool = True,
    ) -> dict[str, Any]:
        url = path if path.startswith("http://") or path.startswith("https://") else urljoin(
            f"{self.base_url}/", path.lstrip("/")
        )

        data = None
        headers = {
            "Accept": "application/json",
            "User-Agent": "domecdn-auto-renew/1.0",
        }

        if payload is not None:
            data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
            headers["Content-Type"] = "application/json"

        if include_token and self.access_token:
            headers["access-token"] = self.access_token

        request = Request(url=url, data=data, headers=headers, method=method.upper())

        try:
            with self._opener.open(request, timeout=self.timeout) as response:
                raw = response.read().decode("utf-8", errors="replace")
                status = response.getcode()
        except HTTPError as exc:
            raw = exc.read().decode("utf-8", errors="replace")
            status = exc.code
        except URLError as exc:
            raise ApiError(f"请求失败: {exc}") from exc

        try:
            parsed = json.loads(raw)
        except json.JSONDecodeError as exc:
            raise ApiError("接口返回不是合法 JSON", status=status, body=raw) from exc

        code = parsed.get("code")
        if code != 0:
            raise ApiError(
                parsed.get("msg") or f"接口返回异常: {code}",
                code=code,
                status=status,
                body=raw,
            )

        return parsed

    def login(self, account: str, password: str) -> dict[str, Any]:
        response = self.request(
            "POST",
            "/login",
            payload={
                "account": account,
                "password": password,
                "code": "",
                "captcha": "",
            },
            include_token=False,
        )
        data = response.get("data")
        if not isinstance(data, dict):
            raise ApiError("登录成功但未拿到 access_token", body=json_dump(response))

        access_token = data.get("access_token")
        if not access_token:
            raise ApiError("登录成功但响应中没有 access_token", body=json_dump(response))

        self.access_token = str(access_token)
        return data

    def get_overview(self) -> dict[str, Any]:
        return self.request("GET", "/user/overview").get("data") or {}

    def get_menu(self) -> list[dict[str, Any]]:
        data = self.request("GET", "/common/menu?v=4.0.0").get("data")
        return normalize_list(data)

    def list_sites(self, *, page: int = 1, limit: int = 200) -> list[dict[str, Any]]:
        query = urlencode({"page": page, "limit": limit})
        data = self.request("GET", f"/sites?{query}").get("data")
        return normalize_list(data)

    def list_orders(
        self,
        *,
        page: int = 1,
        limit: int = 50,
        order_type: str | None = None,
    ) -> list[dict[str, Any]]:
        params: dict[str, Any] = {"page": page, "limit": limit}
        if order_type:
            params["type"] = order_type
        query = urlencode(params)
        data = self.request("GET", f"/orders?{query}").get("data")
        return normalize_list(data)

    def list_user_packages(self, *, page: int = 1, limit: int = 100) -> list[dict[str, Any]]:
        query = urlencode({"page": page, "limit": limit})
        data = self.request("GET", f"/user-packages?{query}").get("data")
        return normalize_list(data)

    def list_packages(self, *, page: int = 1, limit: int = 200) -> list[dict[str, Any]]:
        query = urlencode({"page": page, "limit": limit})
        data = self.request("GET", f"/packages?{query}").get("data")
        return normalize_list(data)

    def get_renew_quote(self, user_package_id: int, duration: str) -> dict[str, Any]:
        query = urlencode({"duration": duration})
        return self.request("GET", f"/user-packages/{user_package_id}?{query}").get("data") or {}

    def renew_user_package(self, user_package_id: int, duration: str) -> dict[str, Any]:
        return self.request(
            "PUT",
            f"/user-packages/{user_package_id}",
            payload={"duration": duration},
        ).get("data") or {}


def load_settings(env_file: Path | None) -> Settings:
    if env_file is not None:
        load_env_file(env_file)

    return Settings(
        base_url=os.getenv("DOMECDN_BASE_URL", DEFAULT_BASE_URL).strip() or DEFAULT_BASE_URL,
        timeout=float(os.getenv("DOMECDN_TIMEOUT", str(DEFAULT_TIMEOUT))),
        account=os.getenv("DOMECDN_ACCOUNT"),
        password=os.getenv("DOMECDN_PASSWORD"),
        access_token=os.getenv("DOMECDN_ACCESS_TOKEN"),
        renew_duration=os.getenv("DOMECDN_RENEW_DURATION", "month").strip() or "month",
        renew_threshold_days=int(os.getenv("DOMECDN_RENEW_THRESHOLD_DAYS", "3")),
        free_only=os.getenv("DOMECDN_FREE_ONLY", "0").strip() in {"1", "true", "TRUE", "yes", "YES"},
    )


def build_client(settings: Settings) -> tuple[DomeCdnClient, str]:
    client = DomeCdnClient(
        settings.base_url,
        timeout=settings.timeout,
        access_token=settings.access_token,
    )

    if settings.access_token:
        return client, "access_token"

    if not settings.account or not settings.password:
        raise ConfigError(
            "未提供 DOMECDN_ACCESS_TOKEN，且 DOMECDN_ACCOUNT / DOMECDN_PASSWORD 不完整。"
        )

    client.login(settings.account, settings.password)
    return client, "login"


def brief_site(site: dict[str, Any]) -> dict[str, Any]:
    return {
        "id": site.get("id"),
        "uid": site.get("uid"),
        "domain": site.get("domain"),
        "package_name": site.get("package_name"),
        "site_state": site.get("site_state"),
        "enable": site.get("enable"),
    }


def brief_order(order: dict[str, Any]) -> dict[str, Any]:
    return {
        "id": order.get("id"),
        "type": order.get("type"),
        "state": order.get("state"),
        "amount": format_amount_cents(order.get("amount")),
        "des": order.get("des"),
        "create_at2": order.get("create_at2"),
        "data": order.get("data"),
    }


def brief_user_package(user_package: dict[str, Any]) -> dict[str, Any]:
    return {
        "id": user_package.get("id"),
        "uid": user_package.get("uid"),
        "name": user_package.get("name") or user_package.get("package_name"),
        "package": user_package.get("package"),
        "package_name": user_package.get("package_name"),
        "enable": user_package.get("enable"),
        "start_at": user_package.get("start_at") or user_package.get("start_at2"),
        "end_at": user_package.get("end_at") or user_package.get("end_at2"),
        "state": user_package.get("state"),
    }


def inspect_account(
    client: DomeCdnClient,
    settings: Settings,
    state: str,
    site_limit: int,
    order_limit: int,
    package_limit: int,
) -> dict[str, Any]:
    result: dict[str, Any] = {"warnings": []}
    package_map: dict[int, dict[str, Any]] = {}

    overview = client.get_overview()
    result["overview"] = {
        "uid": overview.get("uid"),
        "balance": overview.get("balance"),
        "renew": overview.get("renew"),
        "domain_count": overview.get("domain_count"),
        "cert_count": overview.get("cert_count"),
        "stream_port_count": overview.get("stream_port_count"),
    }

    try:
        sites = client.list_sites(limit=site_limit)
        expired_sites = [brief_site(site) for site in sites if site_is_expired(site, state)]
        result["expired_sites"] = expired_sites
        result["expired_site_count"] = len(expired_sites)
    except ApiError as exc:
        result["warnings"].append(f"读取站点列表失败: {exc}")
        result["expired_sites"] = []
        result["expired_site_count"] = 0

    try:
        orders = client.list_orders(limit=order_limit, order_type="续费")
        result["recent_renew_orders"] = [brief_order(order) for order in orders[:order_limit]]
    except ApiError as exc:
        result["warnings"].append(f"读取订单列表失败: {exc}")
        result["recent_renew_orders"] = []

    try:
        packages = client.list_packages(limit=package_limit)
        package_map = {
            int(item["id"]): item
            for item in packages
            if isinstance(item, dict) and safe_int(item.get("id")) is not None
        }
    except ApiError as exc:
        result["warnings"].append(f"读取基础套餐列表失败: {exc}")

    try:
        user_packages = client.list_user_packages(limit=package_limit)
        now = datetime.now()
        inspected_user_packages: list[dict[str, Any]] = []
        renewable_candidates: list[dict[str, Any]] = []

        for item in user_packages[:package_limit]:
            package_id = safe_int(item.get("package"))
            package_info = package_map.get(package_id) if package_id is not None else None
            threshold_days = resolve_threshold_days(package_info, settings.renew_threshold_days)
            days_left = calc_days_left(item.get("end_at2") or item.get("end_at"), now)

            row = {
                **brief_user_package(item),
                "days_left": days_left,
                "renew_threshold_days": threshold_days,
                "before_exp_days_renew": (
                    package_info.get("before_exp_days_renew")
                    if isinstance(package_info, dict)
                    else None
                ),
            }
            inspected_user_packages.append(row)

            if days_left is not None and days_left <= threshold_days:
                renewable_candidates.append(row)

        result["user_packages"] = inspected_user_packages
        result["renewable_candidates"] = renewable_candidates
    except ApiError as exc:
        result["warnings"].append(f"读取用户套餐列表失败: {exc}")
        result["user_packages"] = []
        result["renewable_candidates"] = []

    try:
        menu = client.get_menu()
        result["menu_entries"] = [item.get("title") for item in menu if item.get("title")]
    except ApiError as exc:
        result["warnings"].append(f"读取菜单失败: {exc}")
        result["menu_entries"] = []

    return result


def plan_renew(
    client: DomeCdnClient,
    settings: Settings,
    *,
    state: str,
    site_limit: int,
    package_limit: int,
    manual_ids: list[int],
    duration: str,
    threshold_days: int | None,
    execute: bool,
) -> dict[str, Any]:
    if duration not in {"month", "quarter", "year"}:
        raise ConfigError("duration 只支持: month / quarter / year")

    overview = client.get_overview()
    balance = safe_float(overview.get("balance")) or 0.0

    sites = client.list_sites(limit=site_limit)
    site_map: dict[int, dict[str, Any]] = {}
    for site in sites:
        user_package_id = safe_int(site.get("user_package"))
        if user_package_id is not None:
            site_map[user_package_id] = site

    packages = client.list_packages(limit=package_limit)
    package_map = {
        int(item["id"]): item
        for item in packages
        if isinstance(item, dict) and safe_int(item.get("id")) is not None
    }

    user_packages = client.list_user_packages(limit=package_limit)
    indexed_user_packages = {
        int(item["id"]): item
        for item in user_packages
        if isinstance(item, dict) and safe_int(item.get("id")) is not None
    }

    actions: list[dict[str, Any]] = []
    target_ids = manual_ids or sorted(indexed_user_packages.keys())
    now = datetime.now()

    for user_package_id in target_ids:
        target = indexed_user_packages.get(user_package_id)
        if target is None:
            actions.append(
                {
                    "resource_id": user_package_id,
                    "executed": False,
                    "eligible": False,
                    "reason": "未找到该 user_package",
                }
            )
            continue

        package_id = safe_int(target.get("package"))
        package_info = package_map.get(package_id) if package_id is not None else None
        resolved_threshold = (
            threshold_days
            if threshold_days is not None
            else resolve_threshold_days(package_info, settings.renew_threshold_days)
        )
        end_at = target.get("end_at2") or target.get("end_at")
        days_left = calc_days_left(end_at, now)
        site = site_map.get(user_package_id)
        site_state = site.get("site_state") if isinstance(site, dict) else None
        due = bool(manual_ids) or days_left is None or days_left <= resolved_threshold or str(site_state) == state

        quote = client.get_renew_quote(user_package_id, duration)
        total_price = safe_float(quote.get("total_price")) or 0.0
        affordable = total_price <= balance
        free_only_ok = (not settings.free_only) or total_price == 0.0
        eligible = due and affordable and free_only_ok

        reason_parts: list[str] = []
        if not due:
            reason_parts.append(f"未到续费窗口(days_left={days_left}, threshold={resolved_threshold})")
        if not affordable:
            reason_parts.append(f"余额不足(balance={balance}, total_price={total_price})")
        if not free_only_ok:
            reason_parts.append(f"非 0 元续费(total_price={total_price})")
        if not reason_parts:
            reason_parts.append("可续费")

        action = {
            "resource_id": user_package_id,
            "resource": {
                **brief_user_package(target),
                "site_domain": site.get("domain") if isinstance(site, dict) else None,
                "site_state": site_state,
            },
            "duration": duration,
            "days_left": days_left,
            "renew_threshold_days": resolved_threshold,
            "quote": {
                "basic_price": quote.get("basic_price"),
                "up_price": quote.get("up_price"),
                "total_price": quote.get("total_price"),
            },
            "balance": balance,
            "eligible": eligible,
            "reason": "；".join(reason_parts),
            "executed": False,
        }

        if execute and eligible:
            response = client.renew_user_package(user_package_id, duration)
            action["executed"] = True
            action["response"] = response

        actions.append(action)

    return {
        "target_count": len(actions),
        "execute": execute,
        "actions": actions,
    }


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="DOME CDN 自动巡检/续费脚本。默认只做 dry-run，不会真实提交续费。",
    )
    parser.add_argument(
        "--env-file",
        default=str(SCRIPT_DIR / ENV_FILE_NAME),
        help="环境变量文件路径，默认读取脚本目录下的 .env",
    )
    parser.add_argument(
        "--json",
        action="store_true",
        help="以 JSON 输出结果",
    )

    subparsers = parser.add_subparsers(dest="command")

    inspect_parser = subparsers.add_parser("inspect", help="读取账户概览、站点、订单和套餐信息")
    inspect_parser.add_argument("--state", default="512", help="用于识别过期站点的状态码，默认 512")
    inspect_parser.add_argument("--site-limit", type=int, default=200, help="读取站点数量上限")
    inspect_parser.add_argument("--order-limit", type=int, default=20, help="读取续费订单数量上限")
    inspect_parser.add_argument("--package-limit", type=int, default=50, help="读取用户套餐数量上限")

    renew_parser = subparsers.add_parser("renew", help="按 DOME CDN 固定接口生成续费计划，默认 dry-run")
    renew_parser.add_argument("--state", default="512", help="用于识别过期站点的状态码，默认 512")
    renew_parser.add_argument("--site-limit", type=int, default=200, help="自动读取站点数量上限")
    renew_parser.add_argument("--package-limit", type=int, default=100, help="读取用户套餐数量上限")
    renew_parser.add_argument(
        "--resource-id",
        action="append",
        type=int,
        default=[],
        help="手动指定要续费的 user_package ID，可重复传入",
    )
    renew_parser.add_argument(
        "--duration",
        choices=["month", "quarter", "year"],
        help="续费时长，默认读取 DOMECDN_RENEW_DURATION",
    )
    renew_parser.add_argument(
        "--threshold-days",
        type=int,
        help="覆盖自动续费窗口天数；不传则优先使用套餐配置，再回退到环境变量",
    )
    renew_parser.add_argument(
        "--execute",
        action="store_true",
        help="真实执行续费请求。不加该参数时只输出计划，不发起续费。",
    )
    renew_parser.add_argument(
        "--confirm",
        default="",
        help="真实执行时必须传入 LIVE_RENEWAL，防止误操作",
    )

    return parser


def print_human_inspect(result: dict[str, Any], auth_mode: str) -> None:
    overview = result["overview"]
    print(f"认证方式: {auth_mode}")
    print(f"余额: {overview.get('balance')} 元")
    print(f"待续费: {overview.get('renew')}")
    print(f"站点总数: {overview.get('domain_count')}")
    print(f"疑似过期站点: {result.get('expired_site_count', 0)}")
    print(f"进入续费窗口的套餐: {len(result.get('renewable_candidates', []))}")

    if result.get("expired_sites"):
        print("\n过期站点:")
        for site in result["expired_sites"]:
            print(
                f"- ID={site.get('id')} domain={site.get('domain')} "
                f"package={site.get('package_name')} state={site.get('site_state')}"
            )

    if result.get("recent_renew_orders"):
        print("\n最近续费订单:")
        for order in result["recent_renew_orders"]:
            print(
                f"- ID={order.get('id')} state={order.get('state')} "
                f"amount={order.get('amount')} create_at={order.get('create_at2')}"
            )

    if result.get("renewable_candidates"):
        print("\n进入续费窗口的套餐:")
        for item in result["renewable_candidates"]:
            print(
                f"- user_package_id={item.get('id')} "
                f"package={item.get('package_name')} "
                f"end_at={item.get('end_at')} "
                f"days_left={item.get('days_left')} "
                f"threshold={item.get('renew_threshold_days')}"
            )

    if result.get("warnings"):
        print("\n警告:")
        for warning in result["warnings"]:
            print(f"- {warning}")


def print_human_plan(result: dict[str, Any]) -> None:
    print(f"目标数量: {result['target_count']}")
    print(f"是否执行: {'是' if result['execute'] else '否，仅 dry-run'}")
    for action in result["actions"]:
        if "resource" not in action:
            print(f"- user_package_id={action['resource_id']} eligible={action['eligible']} reason={action['reason']}")
            continue

        print(
            f"- user_package_id={action['resource_id']} "
            f"domain={action['resource'].get('site_domain')} "
            f"duration={action['duration']} "
            f"price={action['quote'].get('total_price')} "
            f"balance={action['balance']} "
            f"eligible={action['eligible']} "
            f"executed={action['executed']} "
            f"reason={action['reason']}"
        )


def main() -> int:
    parser = build_parser()
    args = parser.parse_args()

    command = args.command or "inspect"
    env_file = Path(args.env_file) if args.env_file else None

    try:
        settings = load_settings(env_file)
        client, auth_mode = build_client(settings)

        if command == "inspect":
            result = inspect_account(
                client,
                settings,
                args.state,
                args.site_limit,
                args.order_limit,
                args.package_limit,
            )
            output = {"auth_mode": auth_mode, **result}
            if args.json:
                print(json_dump(output))
            else:
                print_human_inspect(output, auth_mode)
            return 0

        if command == "renew":
            if args.execute and args.confirm != "LIVE_RENEWAL":
                raise ConfigError("真实续费前请显式传入: --execute --confirm LIVE_RENEWAL")
            result = plan_renew(
                client,
                settings,
                state=args.state,
                site_limit=args.site_limit,
                package_limit=args.package_limit,
                manual_ids=args.resource_id,
                duration=args.duration or settings.renew_duration,
                threshold_days=args.threshold_days,
                execute=args.execute,
            )
            output = {"auth_mode": auth_mode, **result}
            if args.json:
                print(json_dump(output))
            else:
                print_human_plan(output)
            return 0

        raise ConfigError(f"不支持的命令: {command}")
    except (ConfigError, ApiError) as exc:
        print(f"错误: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
